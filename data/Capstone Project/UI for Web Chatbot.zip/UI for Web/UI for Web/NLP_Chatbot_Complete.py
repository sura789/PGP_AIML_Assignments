#!/usr/bin/env python
# coding: utf-8

# # NLP Chatbot
# 
# ## Domain:
# Industrial safety. NLP based Chatbot.
# 
# ## Context:
# The database comes from one of the biggest industry in Brazil and in the world. It is an urgent need for industries/companies around the
# globe to understand why employees still suffer some injuries/accidents in plants. Sometimes they also die in such environment.
# 
# ## Data Description:
# This The database is basically records of accidents from 12 different plants in 03 different countries which every line in the data is an
# occurrence of an accident.
# Columns description:
# ‣ Data: timestamp or time/date information
# ‣ Countries: which country the accident occurred (anonymised)
# ‣ Local: the city where the manufacturing plant is located (anonymised)
# ‣ Industry sector: which sector the plant belongs to
# ‣ Accident level: from I to VI, it registers how severe was the accident (I means not severe but VI means very severe)
# ‣ Potential Accident Level: Depending on the Accident Level, the database also registers how severe the accident could have been (due to other factors
# involved in the accident)
# ‣ Genre: if the person is male of female
# ‣ Employee or Third Party: if the injured person is an employee or a third party
# ‣ Critical Risk: some description of the risk involved in the accident
# ‣ Description: Detailed description of how the accident happened.
# Link to download the dataset: https://www.kaggle.com/ihmstefanini/industrial-safety-and-health-analytics-database [ for your reference only ]
# 
# ## Project Objective:
# Design a ML/DL based chatbot utility which can help the professionals to highlight the safety risk as per the incident description.

# # Industrial safety. NLP based Chatbot.

# ## PROJECT TASK:

# ## Milestone 1:

# ### Input: Interim report

# ### Process:

# ### Step 1: Import the data

# In[1]:


get_ipython().system('pip install nltk')
get_ipython().system('pip install tensorflow')
get_ipython().system('git clone https://github.com/aimlnlp/google_trans_new')


# In[2]:


import numpy as np
import re
import string
import math
import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import tensorflow as tf
from sklearn.multioutput import MultiOutputClassifier
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import accuracy_score, f1_score, roc_auc_score
from sklearn.linear_model import LogisticRegression
from sklearn.naive_bayes import GaussianNB
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier, BaggingClassifier, AdaBoostClassifier, GradientBoostingClassifier
from xgboost import XGBClassifier
import os
from sklearn.feature_extraction.text import TfidfVectorizer
from nltk import tokenize,stem
import nltk
nltk.download('punkt')
nltk.download('stopwords')
import unicodedata
from google_trans_new.google_trans_new import google_translator 
from nltk.tokenize import word_tokenize
from tqdm import tqdm
from nltk.corpus import stopwords
stop_words = stopwords.words('english')
from sklearn import metrics
from sklearn.metrics import confusion_matrix, classification_report
from keras.utils import np_utils
from keras.layers import Input
from keras.layers.merge import Concatenate
from tensorflow.keras.models import Sequential
from tensorflow.keras import optimizers
from keras.models import Model
from tensorflow.keras.layers import Flatten, Activation, Dense, LSTM, BatchNormalization, Embedding, Dropout, Flatten, Bidirectional, GlobalMaxPool1D
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences
from keras.callbacks import EarlyStopping, ModelCheckpoint
from keras.models import load_model
from keras.utils.vis_utils import plot_model
import warnings
warnings.filterwarnings('ignore')


# **Data** **Import**

# In[3]:


from google.colab import drive
drive.mount('/content/drive/')


# In[4]:


data_URL = '/content/drive/MyDrive/archive (1)/IHMStefanini_industrial_safety_and_health_database_with_accidents_description.csv'


# In[5]:


#data_URL='IHMStefanini_industrial_safety_and_health_database_with_accidents_description.csv'


# In[6]:


df = pd.read_csv(data_URL)


# In[7]:


df.head(5)


# ### Step 2: Data cleansing

# In[8]:


df.drop("Unnamed: 0", axis=1, inplace=True)
df.rename(columns={'Data':'Date', 'Genre':'Gender'}, inplace=True)
df.head()


# In[9]:


df.rename(columns = {'Accident Level':'Accident_Level'}, inplace = True)


# In[10]:


df.shape


# In[11]:


df.info()


# In[12]:


df['Date'].value_counts()


# In[13]:


df['Countries'].value_counts()


# In[14]:


df['Local'].value_counts()


# In[15]:


df['Industry Sector'].value_counts()


# In[16]:


df['Accident_Level'].value_counts()


# In[17]:


df['Potential Accident Level'].value_counts()


# In[18]:


df['Gender'].value_counts()


# In[19]:


df['Employee or Third Party'].value_counts()


# In[20]:


df['Critical Risk'].value_counts()


# In[21]:


from sklearn.preprocessing import LabelEncoder
local_replace = {'Local_01': 1, 'Local_02': 2, 'Local_03': 3, 'Local_04': 4, 'Local_05': 5, 'Local_06': 6, 'Local_07': 7, 'Local_08': 8, 'Local_09': 9, 'Local_10': 10, 'Local_11': 11, 'Local_12': 12}
df['Local'] = df['Local'].map(local_replace)
le = LabelEncoder()
df['Accident_Level'] = le.fit_transform(df['Accident_Level'])
df['Potential Accident Level'] = le.fit_transform(df['Potential Accident Level'])
del local_replace


# In[22]:


df.head()


# In[23]:


df.isnull().sum()


# In[24]:


df.duplicated().sum()


# In[25]:


# Delete duplicate rows
df.drop_duplicates(inplace=True)


# In[26]:


df['Date'] = pd.to_datetime(df['Date'])
df['Year'] = df['Date'].apply(lambda x : x.year)
df['Month'] = df['Date'].apply(lambda x : x.month)
df.head()


# In[27]:


Month = {
    
    1   :  'January',
    2   :  'February',
    3   :  'March',
    4   :  'April',
    5   :  'May',
    6   :  'June',
    7   :  'July',
    8   :  'August',
    9   :  'September',
    10  :  'October',
    11  :  'November',
    12  :  'December'
    
}


# In[28]:


df['Month'] = df['Month'].map(Month)


# In[29]:


df.head()


# In[30]:


df['Critical Risk']=df['Critical Risk'].replace('\nNot applicable','Not applicable')


# **only one column has unclean data**

# In[31]:


df['Critical Risk'].value_counts()


# In[32]:


columns = df[df.columns[~df.columns.isin(['Description', 'Date'])]].columns.tolist()
for cols in columns:
    print(f'Unique values for {cols} is \n{df[cols].unique()}\n')


# In[33]:


df.info()


# ### Data Visualisation
# ### Univariate Analysis

# #### Countries

# In[34]:


plt.figure(figsize=(15,5))
plt.subplot(1,2,1)
sns.countplot(df['Countries']);
plt.xlabel("\nCountries")

plt.figure(figsize=(6,6))
df['Countries'].value_counts().plot.pie(shadow=True,autopct='%1.f%%', explode=(0.1,0.1,0.1))


# **The most affected country from the above dataset is country_01 with around 59% of the accidents with the count of 250**

# #### Local

# In[35]:


plt.figure(figsize=(20,5))
plt.subplot(1,2,1)
sns.countplot(x=df['Local']);
plt.xlabel("\nLocal")



plt.figure(figsize=(8,8))
df['Local'].value_counts().plot.pie(shadow=True,autopct='%1.2f%%', labels=['Local_03','Local_05','Local_01','Local_04','Local_06','Local_10',
                                                'Local_08','Local_02','Local_07','Local_12','Local_11','Local_09'],  explode=(0.1,0.1,0.1,0.1,0.1,0.1,0.1,0.1,0.1,0.1,0.1,0.1));


# **Most accidents happened in Local_03 .Its count is 90 ,which is equivalent to 21.18%.**
# **The second Most Accident happens in local_5 which is equivalent to 13.88%.**

# #### Industry Sector

# In[36]:


plt.figure(figsize=(15,5))
plt.subplot(1,2,1)
sns.countplot(x=df['Industry Sector']);
plt.xlabel("\nIndustry Sector")



plt.figure(figsize=(6,6))
df['Industry Sector'].value_counts().plot.pie(shadow=True,autopct='%1.2f%%',  explode=(0.1,0.1,0.1));


# **Mostly affected sector is Mining sector. 56.71% of accidents occur in Mining sector.**
# 
# 

# #### Gender

# In[37]:


plt.figure(figsize=(15,5))
plt.subplot(1,2,1)
sns.countplot(x=df['Gender']);
plt.xlabel("\nGender")



plt.figure(figsize=(6,6))
df['Gender'].value_counts().plot.pie(shadow=True,autopct='%1.2f%%',  explode=(0.1,0.1));


# **Most affected workers in accidents are male .Their count is 403 ,which is equivalent to 94.82%**

# #### Accident Level

# In[38]:


plt.figure(figsize=(15,5))
plt.subplot(1,2,1)
sns.countplot(x=df['Accident_Level']);
plt.xlabel("\nAccident Level")



plt.figure(figsize=(8,8))
df['Accident_Level'].value_counts().plot.pie(shadow=True,autopct='%1.2f%%',labels=['I', 'II', 'III' ,'IV' ,'V']);


# **Most accidents belongs to "Accident Level - I" .Its count is 316 which is equivalent to 74.35%% of total accidents.**

# #### Potential Accident Level

# In[39]:


plt.figure(figsize=(15,5))
plt.subplot(1,2,1)
sns.countplot(x=df['Potential Accident Level']);
plt.xlabel("\nPotential Accident Level")



plt.figure(figsize=(8,8))
df['Potential Accident Level'].value_counts().plot.pie(shadow=True,autopct='%1.f%%',labels=['IV', 'III', 'II' ,'I' ,'V','VI']);


# **Most "Potential Accident Level" belongs to level IV .Its count is 143 which is equivalent to 33.65% of total potential accidents.**

# #### Employee or Third Party

# In[40]:


plt.figure(figsize=(15,5))
plt.subplot(1,2,1)
sns.countplot(x=df['Employee or Third Party']);
plt.xlabel("\nEmployee or Third Party")



plt.figure(figsize=(8,8))
df['Employee or Third Party'].value_counts().plot.pie(shadow=True,autopct='%1.2f%%');


# **Most affected Employee type are Third party workers .Their count is 189 ,which is equivalent to 44.47%.**

# #### Year

# In[41]:


plt.figure(figsize=(15,5))
plt.subplot(1,2,1)
sns.countplot(x=df['Year']);
plt.xlabel("\nYears")



plt.figure(figsize=(8,8))
df['Year'].value_counts().plot.pie(shadow=True,autopct='%1.2f%%');


# **Most accidents happend in year 2016.Count is 285 ,which is equivalent to 67.06% .**

# #### Month

# In[42]:


plt.figure(figsize=(15,5))
sns.countplot(x=df['Month']);
plt.xlabel("\nMonths")



plt.figure(figsize=(8,8))
df['Month'].value_counts().plot.pie(shadow=True,autopct='%1.2f%%');


# **Most accidents happend in Feb month.Count is 61 ,which is equivalent to 14.35%**

# ### Bivariate Analysis

# In[43]:


plt.figure(figsize=(15,6))
plt.subplot(1,2,1)
plt.title('Countries Countplot by Accident Level')
sns.countplot(x='Countries',hue='Accident_Level' , data=df );
plt.subplot(1,2,2)
plt.title('Local Countplot by Accident Level')
sns.countplot(x='Local',hue='Accident_Level' , data=df);

plt.show()


# #### Country Vs Accident Level
# - Accident level I is highest in all countries.                   
# - Most accidents happened in Country_01.
# - Accident level in Country_03 is lesser than other countries.
# 
# #### Local Vs Accident Level
# - Accident level I is highest in almost all localities.
# - Accident level I is highest in Local 3.
# - Local 9,11 and 12 have less accidents level.

# In[44]:


plt.figure(figsize=(15,6))
plt.subplot(1,2,1)
plt.title('Industry Sector Countplot by Accident Level')
sns.countplot(x='Industry Sector',hue='Accident_Level' , data=df );
plt.subplot(1,2,2)
plt.title('Gender Countplot by Accident Level')
sns.countplot(x='Gender',hue='Accident_Level' , data=df);

plt.show()


# #### Industry Sector Vs Accident Level
# - Accident level I is highest in all industry sector (Mining, Metals and Other).
# - Most accidents happened in Mining industry sector.
# - After Accident Level I ,Level II is Highest among al the Industries.
# - There are very few cases for Accident level 5.
# 
# #### Gender Vs Accident Level
# - Accident level I is highest among the Gender.
# - Most accidents happened with male ones.
# - There are very few cases With Females.
# 

# In[45]:


plt.figure(figsize=(15,6))
plt.subplot(1,2,1)
plt.title('Countries Countplot by Employee')
sns.countplot(x="Countries", data=df, hue="Employee or Third Party");
plt.subplot(1,2,2)
plt.title('Countries Countplot by Gender')
sns.countplot(x="Countries", data=df, hue="Gender");


# #### Country vs Employee
# - Country_01 is highest No. of injuries
# - Most accidents happened with Third Party .
# - In Country_02 the most effected ones are Employee
# - Country_03 has Less injuries as compared to other Countries
# 
# #### Country Vs Gender
# - Country_01 is highest No. of injuries
# - Most accidents happened with Males.
# - In all Countries the males are Getting effected more .
# - Country_03 has not even single Females 

# In[46]:


plt.figure(figsize=(15,6))
plt.subplot(1,2,1)
plt.title('Local Countplot by Employee')
sns.countplot(x="Local", data=df, hue="Employee or Third Party");
plt.subplot(1,2,2)
plt.title('Local Countplot by Industry Sector')
sns.countplot(x="Local", data=df, hue="Industry Sector");


# #### Local Vs Employees 
# 
# - Local 3 has highest no of Third Party employees
# - Local 3 has more employees than other localities.
# - Local 10,11 don't have Third Party (Remote) employees.
# - Local 8,10,11 don't have Employee and Third Party employees.
# 
# #### Local Vs Industry Sector 
# 
# - Local 3 has highest number of Mining industry sector.
# - Local 5 has highest number of Metals industry sector.
# - Local 1,2,3,4,7 has Mining industry sector.
# - Local 5,6,7,8 has Metals industry sector.
# - Local 10,11,12 has Others industry sector.

# ### Step 3: Data preprocessing

# In[47]:


df.head()


# #### Lower Case

# In[48]:


df['Processed_Description'] = df['Description'].str.lower()
df['Processed_Description']


#  #### Expand Contractions

# In[49]:


contractions_dict = {"ain't": "are not","'s":" is","aren't": "are not"}
# Regular expression for finding contractions
contractions_re=re.compile('(%s)' % '|'.join(contractions_dict.keys()))
def expand_contractions(text,contractions_dict=contractions_dict):
    def replace(match):
        return contractions_dict[match.group(0)]
    return contractions_re.sub(replace, text)
# Expanding Contractions in the reviews
df['Processed_Description']=df['Processed_Description'].apply(lambda x:expand_contractions(x))


# In[50]:


df['Processed_Description']


# #### Remove punctuations

# In[51]:


df['Processed_Description'] = df['Processed_Description'].apply(lambda x: re.sub('[%s]' % re.escape(string.punctuation), '' , x))


# In[52]:


df['Processed_Description']


# #### Remove Stopwords

# In[53]:


#remove stopwords
from nltk.corpus import stopwords
stop_words = set(stopwords.words('english'))
stop_words.add('subject')
stop_words.add('http')
def remove_stopwords(text):
    return " ".join([word for word in str(text).split() if word not in stop_words])
df['Processed_Description'] = df['Processed_Description'].apply(lambda x: remove_stopwords(x))


# In[54]:


df['Processed_Description']


# ####  Lemmatization

# In[55]:


import nltk
nltk.download('wordnet')
nltk.download('omw-1.4')


# In[56]:


#lemmatization
from nltk.stem import WordNetLemmatizer
lemmatizer = WordNetLemmatizer()
def lemmatize_words(text):
    return " ".join([lemmatizer.lemmatize(word) for word in text.split()])
df['Processed_Description'] = df['Processed_Description'].apply(lambda text: lemmatize_words(text))


# In[57]:


df['Processed_Description']


# #### Remove Extra Spaces

# In[58]:


df['Processed_Description'] = df['Processed_Description'].apply(lambda text: re.sub(' +', ' ', text))


# In[59]:


df['Processed_Description']


# #### Tokenization and keeping alphabets

# In[60]:


#defining function for tokenization
stop=set(stopwords.words('english'))
import re
def tokenization(text):
    c=[]
    for desc in text:
        words=[w for w in word_tokenize(desc) if (w not in stop)]
        words = [word for word in words if word.isalpha()]
        c.append(words)
    return c 


# In[61]:


df['Processed_Description']= tokenization(df['Processed_Description'])


# In[62]:


df['Processed_Description']


# #### Maximum length of the sentence

# In[63]:


leng = []
for i in df['Processed_Description']:
    leng.append(len(i))
print('Maximum length of the sentence in processed description :',max(leng))


# #### Processing the description

# In[64]:


desc_processed = []
desc_processed = [' '.join(i) for i in df.Processed_Description]


# In[65]:


df['Processed_Description_Final'] = desc_processed


# In[66]:


df.head()


# #### Word Cloud

# In[67]:


from wordcloud import WordCloud, STOPWORDS, ImageColorGenerator


# In[68]:


stopwords = set(STOPWORDS)

# Generate a word cloud image
desc = df['Processed_Description_Final']
wordcloud = WordCloud(stopwords = stopwords, background_color = "black").generate(str(desc))

# Display the generated image:
# the matplotlib way:
plt.figure(figsize = [18, 18])
plt.imshow(wordcloud, interpolation = 'bilinear')
plt.axis("off")


# In[69]:


df_AccidentLevel_1 = df[df['Accident_Level'] == 0]


# In[70]:


df_AccidentLevel_2 = df[df['Accident_Level'] == 1]


# In[71]:


df_AccidentLevel_3 = df[df['Accident_Level'] == 2]


# In[72]:


df_AccidentLevel_4 = df[df['Accident_Level'] == 3]


# In[73]:


df_AccidentLevel_5 = df[df['Accident_Level'] == 4]


# In[74]:


df_AccidentLevel_1['Processed_Description_Final']


# In[75]:


df_AccidentLevel_2['Processed_Description_Final']


# In[76]:


df_AccidentLevel_3['Processed_Description_Final']


# In[77]:


df_AccidentLevel_4['Processed_Description_Final']


# In[78]:


df_AccidentLevel_5['Processed_Description_Final']


# #### Word Cloud for Accident Level 1

# In[79]:


stopwords = set(STOPWORDS)

# Generate a word cloud image
desc = df_AccidentLevel_1['Processed_Description_Final']
wordcloud = WordCloud(stopwords = stopwords, background_color = "black").generate(str(desc))

# Display the generated image:
# the matplotlib way:
plt.figure(figsize = [18, 18])
plt.imshow(wordcloud, interpolation = 'bilinear')
plt.axis("off")


# ### Word Cloud for Accident Level 2

# In[80]:


stopwords = set(STOPWORDS)

# Generate a word cloud image
desc = df_AccidentLevel_2['Processed_Description_Final']
wordcloud = WordCloud(stopwords = stopwords, background_color = "black").generate(str(desc))

# Display the generated image:
# the matplotlib way:
plt.figure(figsize = [18, 18])
plt.imshow(wordcloud, interpolation = 'bilinear')
plt.axis("off")


# ### Word Cloud for Accident Level 3

# In[81]:


stopwords = set(STOPWORDS)

# Generate a word cloud image
desc = df_AccidentLevel_3['Processed_Description_Final']
wordcloud = WordCloud(stopwords = stopwords, background_color = "black").generate(str(desc))

# Display the generated image:
# the matplotlib way:
plt.figure(figsize = [18, 18])
plt.imshow(wordcloud, interpolation = 'bilinear')
plt.axis("off")


# ### Word Cloud for Accident Level 4

# In[82]:


stopwords = set(STOPWORDS)

# Generate a word cloud image
desc = df_AccidentLevel_4['Processed_Description_Final']
wordcloud = WordCloud(stopwords = stopwords, background_color = "black").generate(str(desc))

# Display the generated image:
# the matplotlib way:
plt.figure(figsize = [18, 18])
plt.imshow(wordcloud, interpolation = 'bilinear')
plt.axis("off")


# ### Word Cloud for Accident Level 5

# In[83]:


stopwords = set(STOPWORDS)

# Generate a word cloud image
desc = df_AccidentLevel_5['Processed_Description_Final']
wordcloud = WordCloud(stopwords = stopwords, background_color = "black").generate(str(desc))

# Display the generated image:
# the matplotlib way:
plt.figure(figsize = [18, 18])
plt.imshow(wordcloud, interpolation = 'bilinear')
plt.axis("off")


# ### Step 4: Data preparation to be used for AIML model learning

# In[84]:


df
df.head()


# In[85]:


df.drop(columns=['Processed_Description'],axis=1,inplace=True)


# In[86]:


df


# #### Export Clean Data to CSV

# In[87]:


#df.to_csv('/content/drive/MyDrive/archive (1)/IHMStefanini_industrial_safety_and_health_database_with_accidents_description_Cleaned.csv')


# In[88]:


df.to_csv('IHMStefanini_industrial_safety_and_health_database_with_accidents_description_Cleaned.csv')


# #### Getting Target variable

# In[89]:


X= df['Processed_Description_Final']


# In[90]:


y = df['Accident_Level']


# #### Split data into train and test.

# In[91]:


# split X and y into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X,y, random_state=42,test_size = 0.2)


# In[92]:


print(X_train.shape)
print(y_train.shape)


# In[93]:


print(X_test.shape)
print(y_test.shape)


# In[94]:


X_test


# In[95]:


y_test


# ## Milestone 2:

# ### Input: Output of milestone 1

# 
# ### Process:
# 
# 

# ### Step 1: Feature Engineering

# #### Bag Of Words.

# In[96]:


from sklearn.feature_extraction.text import CountVectorizer

vectorizer = CountVectorizer(binary=True, ngram_range=(1, 1), max_features=50)
X_train_bow = vectorizer.fit_transform(X_train)
X_test_bow = vectorizer.transform(X_test)


# In[97]:


vectorizer.get_feature_names()[:5]


# #### View term-document matrix

# In[98]:


X_train_bow.toarray()


# In[99]:


X_train_bow.shape


# In[100]:


X_test_bow.shape


# #### TF-IDF

# In[101]:


# Initializing TfidfVectorizer object
tfIdfVectorizer = TfidfVectorizer(max_features=50)
X_train_tf = tfIdfVectorizer.fit_transform(X_train)
X_test_tf = tfIdfVectorizer.transform(X_test)


# In[102]:


tfIdfVectorizer.get_feature_names()[:5]


# In[103]:


X_train_tf.toarray()


# In[104]:


X_train_tf.shape


# In[105]:


X_test_tf.shape


# #### Word2Vec
# 
# 
# 

# In[106]:


pip install -U gensim


# In[107]:


import gensim
from gensim.models import Word2Vec


# In[108]:


# Converting the words back to the sentence form for modelling
def word_vector(tokens, size):
    vec = np.zeros(size).reshape((1, size))
    count = 0.
    for word in tokens:
        try:
            vec += wv_model.wv[word].reshape((1, size))
            count += 1.
        except KeyError: # handling the case where the token is not in vocabulary
                         
            continue
    if count != 0:
        vec /= count
    return vec


# In[109]:


training = X.tolist() # Covnerting the text to list
training = [sentence.split(' ')  for sentence in training] # Splitting on each sentence which gives the multi dimensional list 
np.array(training[0]) # Priting the first sentence


# In[110]:


# Initiation of Word2Vec model
# Every word represented by 100 dimensions, ignore words which appears less than 2 times, and use cbow model

wv_model = Word2Vec(sentences=training,
                 min_count =2,
                 sg=0, 
                 vector_size=100)
print(wv_model)


# In[111]:


vectors = wv_model.wv.vectors # Storing the vectors of words which is trained on word2vec model


# In[112]:


vectors.shape


# In[113]:


tokenized_words = [i.split() for i in X]
wordvec_arrays = np.zeros((len(tokenized_words), 100))

for i in range(len(tokenized_words)):
    wordvec_arrays[i,:] = word_vector(tokenized_words[i], 100)
    
wordvec_df = pd.DataFrame(wordvec_arrays)
wordvec_df.shape


# In[114]:


# Splitting the data on word2vec embeddings
xtrain_w2v, xtest_w2v,ytrain_w2v,ytest_w2v= train_test_split(wordvec_df,y.values, random_state=42, test_size=0.2)


# In[115]:


xtrain_w2v.shape


# In[116]:


ytrain_w2v.shape


# In[117]:


xtest_w2v.shape


# #### Skipgram

# In[118]:


# Converting the words back to the sentence form for modelling
def word_vector_sg(tokens, size):
    vec = np.zeros(size).reshape((1, size))
    count = 0.
    for word in tokens:
        try:
            vec += wv_model_sg.wv[word].reshape((1, size))
            count += 1.
        except KeyError: # handling the case where the token is not in vocabulary
                         
            continue
    if count != 0:
        vec /= count
    return vec


# In[119]:


wv_model_sg = Word2Vec(sentences=training,
                 min_count =2,
                 sg=1, 
                 vector_size=100)
print(wv_model_sg)


# In[120]:


tokenized_words = [i.split() for i in X]
wordvec_arrays = np.zeros((len(tokenized_words), 100))

for i in range(len(tokenized_words)):
    wordvec_arrays[i,:] = word_vector_sg(tokenized_words[i], 100)
    
wordvec_sg = pd.DataFrame(wordvec_arrays)
wordvec_sg.shape


# In[121]:


# Splitting the data on word2vec embeddings
xtrain_w2v_sg, xtest_w2v_sg,ytrain_w2v_sg,ytest_w2v_sg= train_test_split(wordvec_sg,y.values, random_state=42, test_size=0.2)


# In[122]:


xtrain_w2v_sg.shape


# In[123]:


xtest_w2v_sg.shape


# #### Glove

# In[124]:


from tqdm import tqdm


# In[125]:


#Using glove embedding from 200d file, which is imported locally into kaggle.
embeddings_index = {}
EMBEDDING_FILE = '/content/drive/MyDrive/glove.6B.200d.txt'
#EMBEDDING_FILE = 'glove.6B.200d.txt'

f = open(EMBEDDING_FILE, encoding="utf8")
for line in tqdm(f):
    values = line.split()
    word = values[0]
    coefs = np.asarray(values[1:], dtype='float32')
    embeddings_index[word] = coefs
f.close()

print('Found %s word vectors.' % len(embeddings_index))


# In[126]:


# this function creates a normalized vector for the whole sentence
def sent2vec(s):
    words = str(s).lower()
    words = word_tokenize(words)
    words = [w for w in words if not w in stop_words]
    words = [w for w in words if w.isalpha()]
    M = []
    for w in words:
        try:
            M.append(embeddings_index[w])
        except:
            continue
    M = np.array(M)
    v = M.sum(axis=0)
    if type(v) != np.ndarray:
        return np.zeros(300)
    return v / np.sqrt((v ** 2).sum())


# In[127]:


# create sentence GLOVE embeddings vectors using the above function for training and validation set
ind_glove_df = [sent2vec(x) for x in tqdm(X)]


# In[128]:


wordvec_gl = pd.DataFrame(ind_glove_df)


# In[129]:


wordvec_gl.shape


# In[130]:


# Splitting the data on word2vec embeddings
xtrain_gl, xtest_gl,ytrain_gl,ytest_gl= train_test_split(wordvec_gl,y.values, random_state=42, test_size=0.2)


# In[131]:


xtrain_gl.shape


# In[132]:


xtest_gl.shape


# #### Fasttext

# In[133]:


from gensim.models import FastText
model_ft = FastText(training, window=5, min_count=5, workers=4,sg=1)


# In[134]:


# Converting the words back to the sentence form for modelling
def word_vector_ft(tokens, size):
    vec = np.zeros(size).reshape((1, size))
    count = 0.
    for word in tokens:
        try:
            vec += model_ft.wv[word].reshape((1, size))
            count += 1.
        except KeyError: # handling the case where the token is not in vocabulary
                         
            continue
    if count != 0:
        vec /= count
    return vec


# In[135]:


tokenized_words = [i.split() for i in X]
wordvec_arrays = np.zeros((len(tokenized_words), 100))

for i in range(len(tokenized_words)):
    wordvec_arrays[i,:] = word_vector_ft(tokenized_words[i], 100)
    
wordvec_ft = pd.DataFrame(wordvec_arrays)
wordvec_ft.shape


# In[136]:


wordvec_ft.head(5)


# In[137]:


# Splitting the data on fasttext embeddings
xtrain_ft, xtest_ft,ytrain_ft,ytest_ft= train_test_split(wordvec_ft,y.values, random_state=42, test_size=0.2)


# In[138]:


xtrain_ft.shape


# In[139]:


xtest_ft.shape


# #### Doc2vec

# In[140]:


from gensim.models.doc2vec import Doc2Vec, TaggedDocument


# In[141]:


tagged_data = [TaggedDocument(d, [i]) for i, d in enumerate(X)]


# In[142]:


len(tagged_data)


# In[143]:


model_d2v = gensim.models.Doc2Vec(dm=1, # dm = 1 for ‘distributed memory’ model
                                  dm_mean=1, # dm_mean = 1 for using mean of the context word vectors
                                  vector_size=100, # no. of desired features
                                  window=5, # width of the context window                                  
                                  negative=7, # if > 0 then negative sampling will be used
                                  min_count=5, # Ignores all words with total frequency lower than 5.                                  
                                  workers=32, # no. of cores                                  
                                  alpha=0.1, # learning rate                                  
                                  seed = 23, # for reproducibility
                                 ) 

model_d2v.build_vocab([i for i in tqdm(tagged_data)])

model_d2v.train(tagged_data,total_examples=len(tagged_data),epochs=15)


# In[144]:


docvec_arrays = np.zeros((len(tagged_data), 100)) 
for i in range(len(tagged_data)):
    docvec_arrays[i,:] = model_d2v.docvecs[i].reshape((1,100))    

docvec_df = pd.DataFrame(docvec_arrays) 
docvec_df.shape


# In[145]:


# Splitting the data on doc2vec embeddings
xtrain_dc, xtest_dc,ytrain_dc,ytest_dc= train_test_split(docvec_df,y.values, random_state=42, test_size=0.2)


# In[146]:


xtrain_dc.shape


# In[147]:


xtest_dc.shape


# ### Step 2: Design, train and test machine learning classifiers

# #### Build classifier Models.

# #### Using BOW Vectorizer

# In[148]:


from sklearn.linear_model import LogisticRegression
from sklearn.multiclass import OneVsRestClassifier
from sklearn.svm import SVC
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score
from sklearn.metrics import f1_score
from sklearn.metrics import precision_score
from sklearn.metrics import recall_score
from sklearn.metrics import roc_auc_score

def build_model_train(X_train, y_train, X_test, y_test):
    models = {
        'LogReg':LogisticRegression(C=1.0, penalty='l1', dual=False, solver='liblinear'), 
        'SVM': SVC(C=1.0, kernel='rbf', degree=3, gamma='scale', decision_function_shape='ovr', random_state=None), 
        'Naive Bayes': GaussianNB(priors=None, var_smoothing=1e-09),
        'KNN': KNeighborsClassifier(n_neighbors=5, weights='uniform', algorithm='auto', leaf_size=30, p=2, metric='minkowski', metric_params=None, n_jobs=None),
        'Random Forest':RandomForestClassifier(n_estimators=100, max_depth=30),
        'Bagging': BaggingClassifier(n_estimators=50, max_samples=.7),
        'AdaBoost': AdaBoostClassifier(n_estimators= 50),
        'Gradient Boost': GradientBoostingClassifier(n_estimators = 50, learning_rate = 0.05),
        'XGBoost': XGBClassifier()
      }
    modelnames = []
    accuracyscorestrain = []
    accuracyscorestest = []
    f1scorestrain = []
    f1scorestest = []
    recallscorestrain = []
    recallscorestest = []
    precisionscorestrain = []
    precisionscorestest = []
    classificationreport = []
    confusionmatrix = []
    for modelname, model in models.items():
        clf = model.fit(X_train, y_train) 
        y_pred_test = model.predict(X_test)
        y_pred_train = model.predict(X_train)
        modelnames.append(modelname)
        accuracyscorestrain.append(accuracy_score(y_train, y_pred_train))
        accuracyscorestest.append(accuracy_score(y_test, y_pred_test))
        f1scorestrain.append(f1_score(y_train, y_pred_train, average='weighted'))
        f1scorestest.append(f1_score(y_test, y_pred_test, average='weighted'))
        recallscorestrain.append(recall_score(y_train, y_pred_train, average='weighted'))
        recallscorestest.append(recall_score(y_test, y_pred_test, average='weighted'))
        precisionscorestrain.append(precision_score(y_train, y_pred_train, average='weighted'))
        precisionscorestest.append(precision_score(y_test, y_pred_test, average='weighted'))
        result_df =  pd.DataFrame({'Model': modelnames, 'Accuracy score Train': accuracyscorestrain, 'Accuracy score Test': accuracyscorestest,
                               
                               'Train F1 Score': f1scorestrain,
                               'Test F1 Score': f1scorestest,
                               'Train Recall': recallscorestrain,
                               'Test Recall': recallscorestest,
                               'Train Precision': precisionscorestrain,
                               'Test Precision': precisionscorestest                               
                          })
  
    
    return result_df


# In[149]:


build_model_train(X_train_bow.toarray(),y_train,X_test_bow.toarray(),y_test)


# **KNN performs best that all other models because it is not overfitting and the Test accuracy increases. Rest of the models are overfitting. SVM also does good but as good as KNN**

# #### Using TF-IDF Vectorizer

# In[150]:


build_model_train(X_train_tf.toarray(), y_train, X_test_tf.toarray(), y_test)


# **Logistic Regression and KNN performs better**

# #### Using Word2vec 

# #### Using CBOW

# In[151]:


build_model_train(xtrain_w2v,ytrain_w2v,xtest_w2v,ytest_w2v)


# **Logistic Regression and SVM performs better**

# #### Using Skipgram

# In[152]:


build_model_train(xtrain_w2v_sg,ytrain_w2v_sg,xtest_w2v_sg,ytest_w2v_sg)


# **Logistic Regression, SVM and KNN performs better**

# #### Using Glove

# In[153]:


build_model_train(xtrain_gl,ytrain_gl,xtest_gl,ytest_gl)


# **Logistic Regression, SVM and KNN performs better**

# #### Using Fasttext

# In[154]:


build_model_train(xtrain_ft,ytrain_ft,xtest_ft,ytest_ft)


# **Logistic Regression, SVM performs better**

# #### Using Doc2vec

# In[155]:


build_model_train(xtrain_dc,ytrain_dc,xtest_dc,ytest_dc)


# **Logistic Regression, SVM and KNN performs better**

# #### Hyperparameter Tuning

# In[156]:


from sklearn.model_selection import RandomizedSearchCV
from sklearn.model_selection import GridSearchCV


# In[157]:


def hypermodel_tuning(X_train, y_train):
    models = [LogisticRegression(),SVC(),GaussianNB(),KNeighborsClassifier(),RandomForestClassifier(),BaggingClassifier(), AdaBoostClassifier(),GradientBoostingClassifier(),XGBClassifier()]
    model_log=["lg","svc","nb","knn", "rf","bc","ab","gbcl","xg"]
    param1 = {'penalty' : ['l1', 'l2', 'elasticnet'],'C' : np.logspace(-4, 4, 20),'solver' : ['lbfgs','newton-cg','liblinear','sag','saga'],'max_iter' : [10, 100,25, 50]}
    param2 = {'kernel': ['rbf','sigmoid','linear'], 'gamma': [1e-2, 1e-3, 1e-4, 1e-5],'C': [0.001, 0.10, 0.1, 10, 25, 50, 100]}
    param3 ={'var_smoothing': np.logspace(0,-9, num=100)}
    param4 =  { 'n_neighbors' : [5,7,9,11,13,15],
               'weights' : ['uniform','distance'],
               'metric' : ['minkowski','euclidean','manhattan']}  
    param5 ={'n_estimators':list(range(10,20)) , 
         'max_depth':list(range(10,20)) , 
         'criterion':['gini','entropy'] ,
         'max_samples':list(range(1,10))}
    param6 ={'n_estimators' : [10, 20, 30, 40, 50],'max_samples' : [0.05, 0.1, 0.2, 0.5]}
    param7={"n_estimators" :[10, 100, 200, 250],"learning_rate":  [0.001, 0.01,0.1, 1.5, 2.5]}
    param8={'n_estimators' : [25, 50 ,75, 100, 200],'learning_rate': [0.001 ,0.01,0.1, 0.5, 1.5],'max_depth': [4, 6, 8,10],'max_features': [10, 12, 17]}
    param9={
        'min_child_weight': [1, 5, 10],
        'gamma': [0.5, 1, 1.5, 2, 5],
        'subsample': [0.6, 0.8, 1.0],
        'colsample_bytree': [0.6, 0.8, 1.0],
        'max_depth': [4, 5,8,10]
        }
    param=[param1,param2,param3,param4,param5,param6,param7,param8,param9]
    best_params=[]
    score=[]
    ran_models=[]
    for i in range(len(models)):
        ran=RandomizedSearchCV(estimator=models[i],param_distributions=param[i], 
                      n_jobs=-1, cv=3, verbose=3)
        ran.fit(X_train, y_train)
        best_params.append(ran.best_params_)
        #score.append(ran.best_score_)
        ran_models.append(models[i])
    return best_params


# #### Hyperparameter tuning for BOW 

# In[158]:


hyper_bow=hypermodel_tuning(X_train_bow.toarray(),y_train)


# In[159]:


hyper_bow


# In[160]:


def build_model_train_bow(X_train, y_train, X_test, y_test):
    models = {
        'LogReg':LogisticRegression(C= 0.012742749857031334,max_iter= 25,penalty= 'l2',solver='liblinear'), 
        'SVM': SVC(C=25,gamma=1e-05,kernel='sigmoid'), 
        'Naive Bayes': GaussianNB(var_smoothing=2.848035868435799e-08),
        'KNN': KNeighborsClassifier(metric='manhattan',n_neighbors=9,weights='uniform'),
        'Random Forest':RandomForestClassifier(criterion='gini',max_depth=19,max_samples=8,n_estimators=16),
        'Bagging': BaggingClassifier(max_samples=0.1,n_estimators=40),
        'AdaBoost': AdaBoostClassifier(learning_rate=0.1,n_estimators=100),
        'Gradient Boost': GradientBoostingClassifier(learning_rate=0.001,max_depth=8,max_features=12,n_estimators=200),
        'XGBoost': XGBClassifier(colsample_bytree=1.0,gamma=0.5,max_depth=10,min_child_weight=10,subsample=1.0)
      }
    modelnames = []
    accuracyscorestrain = []
    accuracyscorestest = []
    f1scorestrain_values = []
    f1scorestest_values = []
    recallscorestrain_values = []
    recallscorestest_values = []
    precisionscorestest_values = []
    precisionscorestrain_values = []
    for modelname, model in models.items():
        clf = model.fit(X_train, y_train) 
        result_test= clf.score(X_test,y_test)
        result_train = clf.score(X_train,y_train)
        y_pred_test = model.predict(X_test)
        y_pred_train = model.predict(X_train)
        modelnames.append(modelname)
        accuracyscorestest.append(result_test)
        accuracyscorestrain.append(result_train)
        f1scorestest_values.append(f1_score(y_test, y_pred_test, average='macro'))
        f1scorestrain_values.append(f1_score(y_train, y_pred_train, average='macro'))
        recallscorestrain_values.append(recall_score(y_train, y_pred_train, average='macro'))
        recallscorestest_values.append(recall_score(y_test, y_pred_test, average='macro'))
        precisionscorestrain_values.append(precision_score(y_train, y_pred_train, average='macro'))
        precisionscorestest_values.append(precision_score(y_test, y_pred_test, average='macro'))
        result_df =  pd.DataFrame({'Model': modelnames, 'Accuracy score Train': accuracyscorestrain, 'Accuracy score Test': accuracyscorestest,
                               
                               'Train F1 Score': f1scorestrain_values,
                               'Test F1 Score': f1scorestest_values,
                               'Train Recall': recallscorestrain_values,
                               'Test Recall': recallscorestest_values,
                               'Train Precision': precisionscorestrain_values,
                               'Test Precision': precisionscorestest_values
                          })
      
    return result_df


# In[161]:


build_model_train_bow(X_train_bow.toarray(),y_train,X_test_bow.toarray(),y_test)


# **All models except Naive Bayes performs well**

# #### Hyperparameter tuning for TF-IDF Vectorizer

# In[162]:


hyper_tf=hypermodel_tuning(X_train_tf.toarray(), y_train)


# In[163]:


hyper_tf


# In[164]:


def build_model_train_tf(X_train, y_train, X_test, y_test):
    models = {
        'LogReg':LogisticRegression(C= 0.012742749857031334,max_iter= 25,penalty= 'l2',solver='liblinear'), 
        'SVM': SVC(C=25,gamma=1e-05,kernel='sigmoid'), 
        'Naive Bayes': GaussianNB(var_smoothing=2.848035868435799e-08),
        'KNN': KNeighborsClassifier(metric='manhattan',n_neighbors=9,weights='uniform'),
        'Random Forest':RandomForestClassifier(criterion='gini',max_depth=19,max_samples=8,n_estimators=16),
        'Bagging': BaggingClassifier(max_samples=0.1,n_estimators=40),
        'AdaBoost': AdaBoostClassifier(learning_rate=0.1,n_estimators=100),
        'Gradient Boost': GradientBoostingClassifier(learning_rate=0.001,max_depth=8,max_features=12,n_estimators=200),
        'XGBoost': XGBClassifier(colsample_bytree=1.0,gamma=0.5,max_depth=10,min_child_weight=10,subsample=1.0)
      }
    modelnames = []
    accuracyscorestrain = []
    accuracyscorestest = []
    f1scorestrain_values = []
    f1scorestest_values = []
    recallscorestrain_values = []
    recallscorestest_values = []
    precisionscorestest_values = []
    precisionscorestrain_values = []
    for modelname, model in models.items():
        clf = model.fit(X_train, y_train) 
        result_test= clf.score(X_test,y_test)
        result_train = clf.score(X_train,y_train)
        y_pred_test = model.predict(X_test)
        y_pred_train = model.predict(X_train)
        modelnames.append(modelname)
        accuracyscorestest.append(result_test)
        accuracyscorestrain.append(result_train)
        f1scorestest_values.append(f1_score(y_test, y_pred_test, average='macro'))
        f1scorestrain_values.append(f1_score(y_train, y_pred_train, average='macro'))
        recallscorestrain_values.append(recall_score(y_train, y_pred_train, average='macro'))
        recallscorestest_values.append(recall_score(y_test, y_pred_test, average='macro'))
        precisionscorestrain_values.append(precision_score(y_train, y_pred_train, average='macro'))
        precisionscorestest_values.append(precision_score(y_test, y_pred_test, average='macro'))
        result_df =  pd.DataFrame({'Model': modelnames, 'Accuracy score Train': accuracyscorestrain, 'Accuracy score Test': accuracyscorestest,
                               
                               'Train F1 Score': f1scorestrain_values,
                               'Test F1 Score': f1scorestest_values,
                               'Train Recall': recallscorestrain_values,
                               'Test Recall': recallscorestest_values,
                               'Train Precision': precisionscorestrain_values,
                               'Test Precision': precisionscorestest_values
                          })
      
    return result_df


# In[165]:


build_model_train_tf(X_train_tf.toarray(), y_train, X_test_tf.toarray(), y_test)


# **Except XGBoost and Naive bayes every model performs well**

# #### Hyperparameter tuning for Word2vec-CBOW

# In[166]:


hyper_cbow=hypermodel_tuning(xtrain_w2v,ytrain_w2v)


# In[167]:


hyper_cbow


# In[168]:


def build_model_train_cbow(X_train, y_train, X_test, y_test):
    models = {
        'LogReg':LogisticRegression(C= 0.08858667904100823,max_iter= 10,penalty= 'l1',solver='saga'), 
        'SVM': SVC(C=25,gamma=0.01,kernel='rbf'), 
        'Naive Bayes': GaussianNB(var_smoothing=2.310129700083158e-07),
        'KNN': KNeighborsClassifier(metric='minkowski',n_neighbors=13,weights='uniform'),
        'Random Forest':RandomForestClassifier(criterion='entropy',max_depth=10,max_samples=2,n_estimators=14),
        'Bagging': BaggingClassifier(max_samples=0.05,n_estimators=20),
        'AdaBoost': AdaBoostClassifier(learning_rate=0.01,n_estimators=200),
        'Gradient Boost': GradientBoostingClassifier(learning_rate=0.1,max_depth=6,max_features=12,n_estimators=100),
        'XGBoost': XGBClassifier(colsample_bytree=0.6,gamma=5,max_depth=5,min_child_weight=1,subsample=1.0)
      }
    modelnames = []
    accuracyscorestrain = []
    accuracyscorestest = []
    f1scorestrain_values = []
    f1scorestest_values = []
    recallscorestrain_values = []
    recallscorestest_values = []
    precisionscorestest_values = []
    precisionscorestrain_values = []
    for modelname, model in models.items():
        clf = model.fit(X_train, y_train) 
        result_test= clf.score(X_test,y_test)
        result_train = clf.score(X_train,y_train)
        y_pred_test = model.predict(X_test)
        y_pred_train = model.predict(X_train)
        modelnames.append(modelname)
        accuracyscorestest.append(result_test)
        accuracyscorestrain.append(result_train)
        f1scorestest_values.append(f1_score(y_test, y_pred_test, average='macro'))
        f1scorestrain_values.append(f1_score(y_train, y_pred_train, average='macro'))
        recallscorestrain_values.append(recall_score(y_train, y_pred_train, average='macro'))
        recallscorestest_values.append(recall_score(y_test, y_pred_test, average='macro'))
        precisionscorestrain_values.append(precision_score(y_train, y_pred_train, average='macro'))
        precisionscorestest_values.append(precision_score(y_test, y_pred_test, average='macro'))
        result_df =  pd.DataFrame({'Model': modelnames, 'Accuracy score Train': accuracyscorestrain, 'Accuracy score Test': accuracyscorestest,
                               
                               'Train F1 Score': f1scorestrain_values,
                               'Test F1 Score': f1scorestest_values,
                               'Train Recall': recallscorestrain_values,
                               'Test Recall': recallscorestest_values,
                               'Train Precision': precisionscorestrain_values,
                               'Test Precision': precisionscorestest_values
                          })
      
    return result_df


# In[169]:


build_model_train_cbow(xtrain_w2v,ytrain_w2v,xtest_w2v,ytest_w2v)


# **All models except Naive Bayes, Gradient Boost performs well**

# #### Hyperparameter tuning for Word2vec-skipgram

# In[170]:


hyper_skip=hypermodel_tuning(xtrain_w2v_sg,ytrain_w2v_sg)


# In[171]:


hyper_skip


# In[172]:


def build_model_train_skip(X_train, y_train, X_test, y_test):
    models = {
        'LogReg':LogisticRegression(C= 0.08858667904100823,max_iter= 100,penalty= 'l2',solver='sag'), 
        'SVM': SVC(C=0.001,gamma=1e-05,kernel='sigmoid'), 
        'Naive Bayes': GaussianNB(var_smoothing=2.310129700083158e-05),
        'KNN': KNeighborsClassifier(metric='minkowski',n_neighbors=15,weights='uniform'),
        'Random Forest':RandomForestClassifier(criterion='entropy',max_depth=13,max_samples=3,n_estimators=12),
        'Bagging': BaggingClassifier(max_samples=0.05,n_estimators=50),
        'AdaBoost': AdaBoostClassifier(learning_rate=0.001,n_estimators=100),
        'Gradient Boost': GradientBoostingClassifier(learning_rate=0.01,max_depth=4,max_features=12,n_estimators=50),
        'XGBoost': XGBClassifier(colsample_bytree=0.8,gamma=2,max_depth=5,min_child_weight=1,subsample=1.0)
      }
    modelnames = []
    accuracyscorestrain = []
    accuracyscorestest = []
    f1scorestrain_values = []
    f1scorestest_values = []
    recallscorestrain_values = []
    recallscorestest_values = []
    precisionscorestest_values = []
    precisionscorestrain_values = []
    for modelname, model in models.items():
        clf = model.fit(X_train, y_train) 
        result_test= clf.score(X_test,y_test)
        result_train = clf.score(X_train,y_train)
        y_pred_test = model.predict(X_test)
        y_pred_train = model.predict(X_train)
        modelnames.append(modelname)
        accuracyscorestest.append(result_test)
        accuracyscorestrain.append(result_train)
        f1scorestest_values.append(f1_score(y_test, y_pred_test, average='macro'))
        f1scorestrain_values.append(f1_score(y_train, y_pred_train, average='macro'))
        recallscorestrain_values.append(recall_score(y_train, y_pred_train, average='macro'))
        recallscorestest_values.append(recall_score(y_test, y_pred_test, average='macro'))
        precisionscorestrain_values.append(precision_score(y_train, y_pred_train, average='macro'))
        precisionscorestest_values.append(precision_score(y_test, y_pred_test, average='macro'))
        result_df =  pd.DataFrame({'Model': modelnames, 'Accuracy score Train': accuracyscorestrain, 'Accuracy score Test': accuracyscorestest,
                               
                               'Train F1 Score': f1scorestrain_values,
                               'Test F1 Score': f1scorestest_values,
                               'Train Recall': recallscorestrain_values,
                               'Test Recall': recallscorestest_values,
                               'Train Precision': precisionscorestrain_values,
                               'Test Precision': precisionscorestest_values
                          })
      
    return result_df


# In[173]:


build_model_train_skip(xtrain_w2v_sg,ytrain_w2v_sg,xtest_w2v_sg,ytest_w2v_sg)


# **All models except Naive bayes and XGBoost performs well**

# #### Hyperparameter tuning for Glove

# In[174]:


hyper_gl=hypermodel_tuning(xtrain_gl,ytrain_gl)


# In[175]:


hyper_gl


# In[176]:


def build_model_train_gl(X_train, y_train, X_test, y_test):
    models = {
        'LogReg':LogisticRegression(C=0.23357214690901212,max_iter= 10,penalty= 'l1',solver='liblinear'), 
        'SVM': SVC(C=0.1,gamma=0.001,kernel='linear'), 
        'Naive Bayes': GaussianNB(var_smoothing=6.579332246575683e-06),
        'KNN': KNeighborsClassifier(metric='euclidean',n_neighbors=13,weights='uniform'),
        'Random Forest':RandomForestClassifier(criterion='gini',max_depth=15,max_samples=7,n_estimators=10),
        'Bagging': BaggingClassifier(max_samples=0.2,n_estimators=20),
        'AdaBoost': AdaBoostClassifier(learning_rate=0.01,n_estimators=250),
        'Gradient Boost': GradientBoostingClassifier(learning_rate=0.01,max_depth=4,max_features=10,n_estimators=200),
        'XGBoost': XGBClassifier(colsample_bytree=1.0,gamma=5,max_depth=10,min_child_weight=10,subsample=0.6)
      }
    modelnames = []
    accuracyscorestrain = []
    accuracyscorestest = []
    f1scorestrain_values = []
    f1scorestest_values = []
    recallscorestrain_values = []
    recallscorestest_values = []
    precisionscorestest_values = []
    precisionscorestrain_values = []
    for modelname, model in models.items():
        clf = model.fit(X_train, y_train) 
        result_test= clf.score(X_test,y_test)
        result_train = clf.score(X_train,y_train)
        y_pred_test = model.predict(X_test)
        y_pred_train = model.predict(X_train)
        modelnames.append(modelname)
        accuracyscorestest.append(result_test)
        accuracyscorestrain.append(result_train)
        f1scorestest_values.append(f1_score(y_test, y_pred_test, average='macro'))
        f1scorestrain_values.append(f1_score(y_train, y_pred_train, average='macro'))
        recallscorestrain_values.append(recall_score(y_train, y_pred_train, average='macro'))
        recallscorestest_values.append(recall_score(y_test, y_pred_test, average='macro'))
        precisionscorestrain_values.append(precision_score(y_train, y_pred_train, average='macro'))
        precisionscorestest_values.append(precision_score(y_test, y_pred_test, average='macro'))
        result_df =  pd.DataFrame({'Model': modelnames, 'Accuracy score Train': accuracyscorestrain, 'Accuracy score Test': accuracyscorestest,
                               
                               'Train F1 Score': f1scorestrain_values,
                               'Test F1 Score': f1scorestest_values,
                               'Train Recall': recallscorestrain_values,
                               'Test Recall': recallscorestest_values,
                               'Train Precision': precisionscorestrain_values,
                               'Test Precision': precisionscorestest_values
                          })
      
    return result_df


# In[177]:


build_model_train_gl(xtrain_gl,ytrain_gl,xtest_gl,ytest_gl)


# **All models except Naive Bayes and Gradient Boost performs well**

# #### Hyperparameter tuning for Fasttext

# In[178]:


hyper_ft=hypermodel_tuning(xtrain_ft,ytrain_ft)


# In[179]:


hyper_ft


# In[180]:


def build_model_train_ft(X_train, y_train, X_test, y_test):
    models = {
        'LogReg':LogisticRegression(C=0.012742749857031334,max_iter= 100,penalty= 'l1',solver='liblinear'), 
        'SVM': SVC(C=0.1,gamma=0.01,kernel='sigmoid'), 
        'Naive Bayes': GaussianNB(var_smoothing=0.12328467394420659),
        'KNN': KNeighborsClassifier(metric='manhattan',n_neighbors=15,weights='distance'),
        'Random Forest':RandomForestClassifier(criterion='gini',max_depth=16,max_samples=2,n_estimators=17),
        'Bagging': BaggingClassifier(max_samples=0.2,n_estimators=50),
        'AdaBoost': AdaBoostClassifier(learning_rate=0.001,n_estimators=100),
        'Gradient Boost': GradientBoostingClassifier(learning_rate=0.01,max_depth=10,max_features=17,n_estimators=50),
        'XGBoost': XGBClassifier(colsample_bytree=0.8,gamma=1,max_depth=5,min_child_weight=10,subsample=0.6)
      }
    modelnames = []
    accuracyscorestrain = []
    accuracyscorestest = []
    f1scorestrain_values = []
    f1scorestest_values = []
    recallscorestrain_values = []
    recallscorestest_values = []
    precisionscorestest_values = []
    precisionscorestrain_values = []
    for modelname, model in models.items():
        clf = model.fit(X_train, y_train) 
        result_test= clf.score(X_test,y_test)
        result_train = clf.score(X_train,y_train)
        y_pred_test = model.predict(X_test)
        y_pred_train = model.predict(X_train)
        modelnames.append(modelname)
        accuracyscorestest.append(result_test)
        accuracyscorestrain.append(result_train)
        f1scorestest_values.append(f1_score(y_test, y_pred_test, average='macro'))
        f1scorestrain_values.append(f1_score(y_train, y_pred_train, average='macro'))
        recallscorestrain_values.append(recall_score(y_train, y_pred_train, average='macro'))
        recallscorestest_values.append(recall_score(y_test, y_pred_test, average='macro'))
        precisionscorestrain_values.append(precision_score(y_train, y_pred_train, average='macro'))
        precisionscorestest_values.append(precision_score(y_test, y_pred_test, average='macro'))
        result_df =  pd.DataFrame({'Model': modelnames, 'Accuracy score Train': accuracyscorestrain, 'Accuracy score Test': accuracyscorestest,
                               
                               'Train F1 Score': f1scorestrain_values,
                               'Test F1 Score': f1scorestest_values,
                               'Train Recall': recallscorestrain_values,
                               'Test Recall': recallscorestest_values,
                               'Train Precision': precisionscorestrain_values,
                               'Test Precision': precisionscorestest_values
                          })
      
    return result_df


# In[181]:


build_model_train_ft(xtrain_ft,ytrain_ft,xtest_ft,ytest_ft)


# **All models except Naive Bayes, KNN, Graient Bosst and XG Boost performs well**

# #### Hyperparameter tuning for Doc2vec

# In[182]:


hyper_dc=hypermodel_tuning(xtrain_dc,ytrain_dc)


# In[183]:


hyper_dc


# In[184]:


def build_model_train_dc(X_train, y_train, X_test, y_test):
    models = {
        'LogReg':LogisticRegression(C=0.03359818286283781,max_iter= 50,penalty= 'l2',solver='saga'), 
        'SVM': SVC(C=50,gamma=0.0001,kernel='rbf'), 
        'Naive Bayes': GaussianNB(var_smoothing=0.0012328467394420659),
        'KNN': KNeighborsClassifier(metric='euclidean',n_neighbors=9,weights='uniform'),
        'Random Forest':RandomForestClassifier(criterion='gini',max_depth=13,max_samples=7,n_estimators=16),
        'Bagging': BaggingClassifier(max_samples=0.05,n_estimators=20),
        'AdaBoost': AdaBoostClassifier(learning_rate=0.001,n_estimators=200),
        'Gradient Boost': GradientBoostingClassifier(learning_rate=0.01,max_depth=10,max_features=12,n_estimators=25),
        'XGBoost': XGBClassifier(colsample_bytree=0.8,gamma=5,max_depth=8,min_child_weight=1,subsample=0.8)
      }
    modelnames = []
    accuracyscorestrain = []
    accuracyscorestest = []
    f1scorestrain_values = []
    f1scorestest_values = []
    recallscorestrain_values = []
    recallscorestest_values = []
    precisionscorestest_values = []
    precisionscorestrain_values = []
    for modelname, model in models.items():
        clf = model.fit(X_train, y_train) 
        result_test= clf.score(X_test,y_test)
        result_train = clf.score(X_train,y_train)
        y_pred_test = model.predict(X_test)
        y_pred_train = model.predict(X_train)
        modelnames.append(modelname)
        accuracyscorestest.append(result_test)
        accuracyscorestrain.append(result_train)
        f1scorestest_values.append(f1_score(y_test, y_pred_test, average='macro'))
        f1scorestrain_values.append(f1_score(y_train, y_pred_train, average='macro'))
        recallscorestrain_values.append(recall_score(y_train, y_pred_train, average='macro'))
        recallscorestest_values.append(recall_score(y_test, y_pred_test, average='macro'))
        precisionscorestrain_values.append(precision_score(y_train, y_pred_train, average='macro'))
        precisionscorestest_values.append(precision_score(y_test, y_pred_test, average='macro'))
        result_df =  pd.DataFrame({'Model': modelnames, 'Accuracy score Train': accuracyscorestrain, 'Accuracy score Test': accuracyscorestest,
                               
                               'Train F1 Score': f1scorestrain_values,
                               'Test F1 Score': f1scorestest_values,
                               'Train Recall': recallscorestrain_values,
                               'Test Recall': recallscorestest_values,
                               'Train Precision': precisionscorestrain_values,
                               'Test Precision': precisionscorestest_values
                          })
      
    return result_df


# In[185]:


build_model_train_dc(xtrain_dc,ytrain_dc,xtest_dc,ytest_dc)


# **All model except KNN performs well**

# ### Step 3 : Design, train and test Neural networks classifiers 

# In[186]:


# disable keras warnings
tf.get_logger().setLevel('ERROR')


# In[187]:


y_train_dummy = pd.get_dummies(y_train)
y_test_dummy = pd.get_dummies(y_test)


# In[188]:


y_train_dummy.shape


# In[189]:


# get the accuracy, precision, recall, f1 score from model
def get_classification_metrics(model, X_test, y_test, target_type):
             
  # predict probabilities for test set
    yhat_probs = model.predict(X_test, verbose=0) # Multiclass

  # predict crisp classes for test set
    if target_type == 'multi_class':
        yhat_classes = model.predict_classes(X_test, verbose=0) # Multiclass
    else:
        yhat_classes = (np.asarray(model.predict(X_test))).round() # Multilabel

  # reduce to 1d array
    yhat_probs = yhat_probs[:, 0]

  # accuracy: (tp + tn) / (p + n)
    accuracy = accuracy_score(y_test, yhat_classes)

  # precision tp / (tp + fp)
    precision = precision_score(y_test, yhat_classes, average='micro')

  # recall: tp / (tp + fn)
    recall = recall_score(y_test, yhat_classes, average='micro')

  # f1: 2 tp / (2 tp + fp + fn)
    f1 = f1_score(y_test, yhat_classes, average='micro')

    return accuracy, precision, recall, f1


# In[190]:


class Metrics(tf.keras.callbacks.Callback):

    def __init__(self, validation_data=()):
        super().__init__()
        self.validation_data = validation_data

    def on_train_begin(self, logs={}):
        self.val_f1s = []
        self.val_recalls = []
        self.val_precisions = []

    def on_epoch_end(self, epoch, logs={}):
        xVal, yVal, target_type = self.validation_data
        if target_type == 'multi_class':
            val_predict_classes = model.predict_classes(xVal, verbose=0) # Multiclass
        else:
            val_predict_classes = (np.asarray(self.model.predict(xVal))).round() # Multilabel
        
        
        val_targ = yVal

        _val_f1 = f1_score(val_targ, val_predict_classes, average='micro')
        _val_recall = recall_score(val_targ, val_predict_classes, average='micro')
        _val_precision = precision_score(val_targ, val_predict_classes, average='micro')
        self.val_f1s.append(_val_f1)
        self.val_recalls.append(_val_recall)
        self.val_precisions.append(_val_precision)
        #print("— train_f1: %f — train_precision: %f — train_recall %f" % (_val_f1, _val_precision, _val_recall))
        return


# #### For BOW

# In[191]:


# fix random seed for reproducibility
seed = 7
np.random.seed(seed)
tf.random.set_seed(seed)

epochs = 100
batch_size = 12
loss = "categorical_crossentropy"
optimizer = "adam"
metrics = ["accuracy"]

early_stopping = EarlyStopping(monitor='val_loss', mode='min', verbose=0, patience=3)

# Build neural network
bow_model = Sequential()
bow_model.add(Dense(512, activation='relu'))
bow_model.add(Dense(256, activation='relu'))
bow_model.add(Dense(5, activation='softmax'))
bow_model.compile(loss=loss, optimizer=optimizer, metrics= metrics)


# In[192]:


history=bow_model.fit(X_train_bow.toarray(), y_train_dummy, validation_split = 0.2, epochs=epochs, batch_size=batch_size, callbacks=[early_stopping])


# In[193]:


# evaluate the keras model
_, train_accuracy = bow_model.evaluate(X_train_bow.toarray(), y_train_dummy, batch_size=8, verbose=0)
_, test_accuracy = bow_model.evaluate(X_test_bow.toarray(), y_test_dummy, batch_size=8, verbose=0)

print('Train accuracy: %.2f' % (train_accuracy*100))
print('Test accuracy: %.2f' % (test_accuracy*100))


# In[194]:


target_type = 'multi_label'
accuracy, precision, recall, f1 = get_classification_metrics(bow_model, X_test_bow.toarray(), y_test_dummy, target_type)
print('Accuracy: %f' % accuracy)
print('Precision: %f' % precision)
print('Recall: %f' % recall)
print('F1 score: %f' % f1)


# In[195]:


plot_model(bow_model, to_file='bow_model.png', show_shapes=True, show_layer_names=True)


# In[196]:


import matplotlib.pyplot as plt

f, (ax1, ax2) = plt.subplots(1, 2, figsize = (15, 7.5))
f.suptitle('Monitoring the performance of the model')

ax1.plot(history.history['loss'], label = 'Train')
ax1.plot(history.history['val_loss'], label = 'Test')
ax1.set_title('Model Loss')
ax1.legend(['Train', 'Test'])

ax2.plot(history.history['accuracy'], label = 'Train')
ax2.plot(history.history['val_accuracy'], label = 'Test')
ax2.set_title('Model Accuracy')
ax2.legend(['Train', 'Test'])

plt.show()


# #### For TF-IDF

# In[197]:


# fix random seed for reproducibility
seed = 7
np.random.seed(seed)
tf.random.set_seed(seed)

epochs = 100
batch_size = 12
loss = "categorical_crossentropy"
optimizer = "adam"
metrics = ["accuracy"]

early_stopping = EarlyStopping(monitor='val_loss', mode='min', verbose=0, patience=3)

# Build neural network
tfidf_model = Sequential()
tfidf_model.add(Dense(512, activation='relu'))
tfidf_model.add(Dense(256, activation='relu'))
tfidf_model.add(Dense(5, activation='softmax'))
tfidf_model.compile(loss=loss, optimizer=optimizer, metrics= metrics)


# In[198]:


history=tfidf_model.fit(X_train_tf.toarray(), y_train_dummy, validation_split = 0.2, epochs=epochs, batch_size=batch_size, callbacks=[early_stopping])


# In[199]:


# evaluate the keras model
_, train_accuracy = tfidf_model.evaluate(X_train_tf.toarray(), y_train_dummy, batch_size=8, verbose=0)
_, test_accuracy = tfidf_model.evaluate(X_test_tf.toarray(), y_test_dummy, batch_size=8, verbose=0)

print('Train accuracy: %.2f' % (train_accuracy*100))
print('Test accuracy: %.2f' % (test_accuracy*100))


# In[200]:


target_type = 'multi_label'
accuracy, precision, recall, f1 = get_classification_metrics(tfidf_model, X_test_tf.toarray(), y_test_dummy, target_type)
print('Accuracy: %f' % accuracy)
print('Precision: %f' % precision)
print('Recall: %f' % recall)
print('F1 score: %f' % f1)


# In[201]:


plot_model(tfidf_model, to_file='tfidf_model.png', show_shapes=True, show_layer_names=True)


# In[202]:


import matplotlib.pyplot as plt

f, (ax1, ax2) = plt.subplots(1, 2, figsize = (15, 7.5))
f.suptitle('Monitoring the performance of the model')

ax1.plot(history.history['loss'], label = 'Train')
ax1.plot(history.history['val_loss'], label = 'Test')
ax1.set_title('Model Loss')
ax1.legend(['Train', 'Test'])

ax2.plot(history.history['accuracy'], label = 'Train')
ax2.plot(history.history['val_accuracy'], label = 'Test')
ax2.set_title('Model Accuracy')
ax2.legend(['Train', 'Test'])

plt.show()


# #### For Word to Vec

# In[203]:


# fix random seed for reproducibility
seed = 7
np.random.seed(seed)
tf.random.set_seed(seed)

epochs = 100
batch_size = 10
loss = "categorical_crossentropy"
optimizer = "adam"
metrics = ["accuracy"]

callbacks = EarlyStopping(monitor='val_loss', mode='min', verbose=0, patience=3)

# Build neural network
cbow_model = Sequential()
cbow_model.add(Dense(512, activation='relu'))
cbow_model.add(Dense(256, activation='relu'))
cbow_model.add(Dense(5, activation='softmax'))
cbow_model.compile(loss=loss, optimizer=optimizer, metrics= metrics)


# In[204]:


history=cbow_model.fit(xtrain_w2v, y_train_dummy, validation_data=(xtest_w2v, y_test_dummy), epochs=epochs, batch_size=batch_size, callbacks=callbacks)


# In[205]:


# evaluate the keras model
_, train_accuracy = cbow_model.evaluate(xtrain_w2v, y_train_dummy, batch_size=8, verbose=0)
_, test_accuracy = cbow_model.evaluate(xtest_w2v, y_test_dummy, batch_size=8, verbose=0)

print('Train accuracy: %.2f' % (train_accuracy*100))
print('Test accuracy: %.2f' % (test_accuracy*100))


# In[206]:


target_type = 'multi_label'
accuracy, precision, recall, f1 = get_classification_metrics(cbow_model, xtest_w2v, y_test_dummy, target_type)
print('Accuracy: %f' % accuracy)
print('Precision: %f' % precision)
print('Recall: %f' % recall)
print('F1 score: %f' % f1)


# In[207]:


plot_model(cbow_model, to_file='cbow_model.png', show_shapes=True, show_layer_names=True)


# In[208]:


import matplotlib.pyplot as plt

f, (ax1, ax2) = plt.subplots(1, 2, figsize = (15, 7.5))
f.suptitle('Monitoring the performance of the model')

ax1.plot(history.history['loss'], label = 'Train')
ax1.plot(history.history['val_loss'], label = 'Test')
ax1.set_title('Model Loss')
ax1.legend(['Train', 'Test'])

ax2.plot(history.history['accuracy'], label = 'Train')
ax2.plot(history.history['val_accuracy'], label = 'Test')
ax2.set_title('Model Accuracy')
ax2.legend(['Train', 'Test'])

plt.show()


# #### For Skipgram

# In[209]:


# fix random seed for reproducibility
seed = 7
np.random.seed(seed)
tf.random.set_seed(seed)

epochs = 100
batch_size = 10
loss = "categorical_crossentropy"
optimizer = "adam"
metrics = ["accuracy"]

callbacks = EarlyStopping(monitor='val_loss', verbose=0, patience=3)

# Build neural network
skipgram_model = Sequential()
skipgram_model.add(Dense(512, activation='relu'))
skipgram_model.add(Dense(256, activation='relu'))
skipgram_model.add(Dense(5, activation='softmax'))
skipgram_model.compile(loss=loss, optimizer=optimizer, metrics= metrics)


# In[210]:


history=skipgram_model.fit(xtrain_w2v_sg, y_train_dummy, validation_data=(xtest_w2v_sg, y_test_dummy), epochs=epochs, batch_size=batch_size, callbacks=callbacks)


# In[211]:


# evaluate the keras model
_, train_accuracy = skipgram_model.evaluate(xtrain_w2v_sg, y_train_dummy, batch_size=8, verbose=0)
_, test_accuracy = skipgram_model.evaluate(xtest_w2v_sg, y_test_dummy, batch_size=8, verbose=0)

print('Train accuracy: %.2f' % (train_accuracy*100))
print('Test accuracy: %.2f' % (test_accuracy*100))


# In[212]:


target_type = 'multi_label'
accuracy, precision, recall, f1 = get_classification_metrics(skipgram_model, xtest_w2v_sg, y_test_dummy, target_type)
print('Accuracy: %f' % accuracy)
print('Precision: %f' % precision)
print('Recall: %f' % recall)
print('F1 score: %f' % f1)


# In[213]:


plot_model(skipgram_model, to_file='skipgram_model.png', show_shapes=True, show_layer_names=True)


# In[214]:


import matplotlib.pyplot as plt

f, (ax1, ax2) = plt.subplots(1, 2, figsize = (15, 7.5))
f.suptitle('Monitoring the performance of the model')

ax1.plot(history.history['loss'], label = 'Train')
ax1.plot(history.history['val_loss'], label = 'Test')
ax1.set_title('Model Loss')
ax1.legend(['Train', 'Test'])

ax2.plot(history.history['accuracy'], label = 'Train')
ax2.plot(history.history['val_accuracy'], label = 'Test')
ax2.set_title('Model Accuracy')
ax2.legend(['Train', 'Test'])

plt.show()


# #### For Fasttext
# 

# In[215]:


# fix random seed for reproducibility
seed = 7
np.random.seed(seed)
tf.random.set_seed(seed)

epochs = 100
batch_size = 10
loss = "categorical_crossentropy"
optimizer = "adam"
metrics = ["accuracy"]

callbacks = EarlyStopping(monitor='val_loss', verbose=0, patience=3)

# Build neural network
fasttext_model = Sequential()
fasttext_model.add(Dense(512, activation='relu'))
fasttext_model.add(Dense(256, activation='relu'))
fasttext_model.add(Dense(5, activation='softmax'))
fasttext_model.compile(loss=loss, optimizer=optimizer, metrics= metrics)


# In[216]:


history=fasttext_model.fit(xtrain_ft, y_train_dummy, validation_data=(xtest_ft, y_test_dummy), epochs=epochs, batch_size=batch_size, callbacks=callbacks)


# In[217]:


# evaluate the keras model
_, train_accuracy = fasttext_model.evaluate(xtrain_ft, y_train_dummy, batch_size=8, verbose=0)
_, test_accuracy = fasttext_model.evaluate(xtest_ft, y_test_dummy, batch_size=8, verbose=0)

print('Train accuracy: %.2f' % (train_accuracy*100))
print('Test accuracy: %.2f' % (test_accuracy*100))


# In[218]:


target_type = 'multi_label'
accuracy, precision, recall, f1 = get_classification_metrics(fasttext_model, xtest_ft, y_test_dummy, target_type)
print('Accuracy: %f' % accuracy)
print('Precision: %f' % precision)
print('Recall: %f' % recall)
print('F1 score: %f' % f1)


# In[219]:


plot_model(fasttext_model, to_file='fasttext_model.png', show_shapes=True, show_layer_names=True)


# In[220]:


import matplotlib.pyplot as plt

f, (ax1, ax2) = plt.subplots(1, 2, figsize = (15, 7.5))
f.suptitle('Monitoring the performance of the model')

ax1.plot(history.history['loss'], label = 'Train')
ax1.plot(history.history['val_loss'], label = 'Test')
ax1.set_title('Model Loss')
ax1.legend(['Train', 'Test'])

ax2.plot(history.history['accuracy'], label = 'Train')
ax2.plot(history.history['val_accuracy'], label = 'Test')
ax2.set_title('Model Accuracy')
ax2.legend(['Train', 'Test'])

plt.show()


# #### For Doc2Vec
# 

# In[221]:


# fix random seed for reproducibility
seed = 7
np.random.seed(seed)
tf.random.set_seed(seed)

epochs = 100
batch_size = 10
loss = "categorical_crossentropy"
optimizer = "adam"
metrics = ["accuracy"]

callbacks = EarlyStopping(monitor='val_loss', verbose=0, patience=3)

# Build neural network
doc2vec_model = Sequential()
doc2vec_model.add(Dense(512, activation='relu'))
doc2vec_model.add(Dense(256, activation='relu'))
doc2vec_model.add(Dense(5, activation='softmax'))
doc2vec_model.compile(loss=loss, optimizer=optimizer, metrics= metrics)


# In[222]:


history=doc2vec_model.fit(xtrain_dc, y_train_dummy, validation_data=(xtest_dc, y_test_dummy), epochs=epochs, batch_size=batch_size, callbacks=callbacks)


# In[223]:


# evaluate the keras model
_, train_accuracy = doc2vec_model.evaluate(xtrain_dc, y_train_dummy, batch_size=8, verbose=0)
_, test_accuracy = doc2vec_model.evaluate(xtest_dc, y_test_dummy, batch_size=8, verbose=0)

print('Train accuracy: %.2f' % (train_accuracy*100))
print('Test accuracy: %.2f' % (test_accuracy*100))


# In[224]:


target_type = 'multi_label'
accuracy, precision, recall, f1 = get_classification_metrics(doc2vec_model, xtest_dc, y_test_dummy, target_type)
print('Accuracy: %f' % accuracy)
print('Precision: %f' % precision)
print('Recall: %f' % recall)
print('F1 score: %f' % f1)


# In[225]:


plot_model(doc2vec_model, to_file='doc2vec_model.png', show_shapes=True, show_layer_names=True)


# In[226]:


import matplotlib.pyplot as plt

f, (ax1, ax2) = plt.subplots(1, 2, figsize = (15, 7.5))
f.suptitle('Monitoring the performance of the model')

ax1.plot(history.history['loss'], label = 'Train')
ax1.plot(history.history['val_loss'], label = 'Test')
ax1.set_title('Model Loss')
ax1.legend(['Train', 'Test'])

ax2.plot(history.history['accuracy'], label = 'Train')
ax2.plot(history.history['val_accuracy'], label = 'Test')
ax2.set_title('Model Accuracy')
ax2.legend(['Train', 'Test'])

plt.show()


# ### Step 4: Design, train and test RNN or LSTM classifiers

# #### For Glove

# In[227]:


# Select input and output features
X_text = df['Processed_Description_Final']
y_text = df['Accident_Level']


# In[228]:


# Encode labels in column 'Accident Level'.
y_text = LabelEncoder().fit_transform(y_text)


# In[229]:


# Divide our data into testing and training sets:
X_text_train, X_text_test, y_text_train, y_text_test = train_test_split(X_text, y_text, test_size = 0.20, random_state = 1, stratify = y_text)

print('X_text_train shape : ({0})'.format(X_text_train.shape[0]))
print('y_text_train shape : ({0},)'.format(y_text_train.shape[0]))
print('X_text_test shape : ({0})'.format(X_text_test.shape[0]))
print('y_text_test shape : ({0},)'.format(y_text_test.shape[0]))


# In[230]:


# Convert both the training and test labels into one-hot encoded vectors:
y_text_train = np_utils.to_categorical(y_text_train)
y_text_test = np_utils.to_categorical(y_text_test)


# In[231]:


# The first step in word embeddings is to convert the words into thier corresponding numeric indexes.
tokenizer = Tokenizer(num_words=5000)
tokenizer.fit_on_texts(X_text_train)

X_text_train = tokenizer.texts_to_sequences(X_text_train)
X_text_test = tokenizer.texts_to_sequences(X_text_test)


# In[232]:


# Sentences can have different lengths, and therefore the sequences returned by the Tokenizer class also consist of variable lengths.
# We need to pad the our sequences using the max length.
vocab_size = len(tokenizer.word_index) + 1
print("vocab_size:", vocab_size)

maxlen = 100

X_text_train = pad_sequences(X_text_train, padding='post', maxlen=maxlen)
X_text_test = pad_sequences(X_text_test, padding='post', maxlen=maxlen)


# In[233]:


# We need to load the built-in GloVe word embeddings
embedding_size = 200
embeddings_dictionary = dict()

glove_file = open('/content/drive/MyDrive/glove.6B.200d.txt', encoding="utf8")
#glove_file = open('glove.6B.200d.txt', encoding="utf8")

for line in glove_file:
    records = line.split()
    word = records[0]
    vector_dimensions = np.asarray(records[1:], dtype='float32')
    embeddings_dictionary[word] = vector_dimensions

glove_file.close()

embedding_matrix = np.zeros((vocab_size, embedding_size))

for word, index in tokenizer.word_index.items():
    embedding_vector = embeddings_dictionary.get(word)
    if embedding_vector is not None:
        embedding_matrix[index] = embedding_vector

len(embeddings_dictionary.values())


# In[234]:


from tensorflow.keras.optimizers import SGD
#reset_random_seeds()

# Build a LSTM Neural Network
deep_inputs = Input(shape=(maxlen,))
embedding_layer = Embedding(vocab_size, embedding_size, weights=[embedding_matrix], trainable=False)(deep_inputs)

LSTM_Layer_1 = Bidirectional(LSTM(128, return_sequences = True))(embedding_layer)
max_pool_layer_1 = GlobalMaxPool1D()(LSTM_Layer_1)
drop_out_layer_1 = Dropout(0.5, input_shape = (256,))(max_pool_layer_1)
dense_layer_1 = Dense(128, activation = 'relu')(drop_out_layer_1)
drop_out_layer_2 = Dropout(0.5, input_shape = (128,))(dense_layer_1)
dense_layer_2 = Dense(64, activation = 'relu')(drop_out_layer_2)
drop_out_layer_3 = Dropout(0.5, input_shape = (64,))(dense_layer_2)

dense_layer_3 = Dense(32, activation = 'relu')(drop_out_layer_3)
drop_out_layer_4 = Dropout(0.5, input_shape = (32,))(dense_layer_3)

dense_layer_4 = Dense(10, activation = 'relu')(drop_out_layer_4)
drop_out_layer_5 = Dropout(0.5, input_shape = (10,))(dense_layer_4)

dense_layer_5 = Dense(5, activation='softmax')(drop_out_layer_5)
#dense_layer_3 = Dense(5, activation='softmax')(drop_out_layer_3)

# LSTM_Layer_1 = LSTM(128)(embedding_layer)
# dense_layer_1 = Dense(5, activation='softmax')(LSTM_Layer_1)
# model = Model(inputs=deep_inputs, outputs=dense_layer_1)

model = Model(inputs=deep_inputs, outputs=dense_layer_5)
#model = Model(inputs=deep_inputs, outputs=dense_layer_3)

opt = SGD(lr=0.001, momentum=0.9)
model.compile(loss='categorical_crossentropy', optimizer=opt, metrics=['acc'])


# In[235]:


print(model.summary())


# In[236]:


plot_model(model, to_file='model_plot1.png', show_shapes=True, show_dtype=True, show_layer_names=True)


# In[237]:


from tensorflow.keras.callbacks import ReduceLROnPlateau
# Use earlystopping
# callback = tf.keras.callbacks.EarlyStopping(monitor='loss', patience=5, min_delta=0.001)
callback = tf.keras.callbacks.EarlyStopping(monitor='loss', patience=7, min_delta=1E-3)
rlrp = ReduceLROnPlateau(monitor='val_loss', factor=0.0001, patience=5, min_delta=1E-4)

target_type = 'multi_label'
metrics = Metrics(validation_data=(X_text_train, y_text_train, target_type))

# fit the keras model on the dataset
training_history = model.fit(X_text_train, y_text_train, epochs=100, batch_size=8, verbose=1, validation_data=(X_text_test, y_text_test), callbacks=[rlrp, metrics])


# In[238]:


# evaluate the keras model
_, train_accuracy = model.evaluate(X_text_train, y_text_train, batch_size=8, verbose=0)
_, test_accuracy = model.evaluate(X_text_test, y_text_test, batch_size=8, verbose=0)

print('Train accuracy: %.2f' % (train_accuracy*100))
print('Test accuracy: %.2f' % (test_accuracy*100))


# In[239]:


accuracy, precision, recall, f1 = get_classification_metrics(model, X_text_test, y_text_test, target_type)
print('Accuracy: %f' % accuracy)
print('Precision: %f' % precision)
print('Recall: %f' % recall)
print('F1 score: %f' % f1)


# In[240]:


epochs = range(len(training_history.history['loss'])) # Get number of epochs

# plot loss learning curves
plt.plot(epochs, training_history.history['loss'], label = 'train')
plt.plot(epochs, training_history.history['val_loss'], label = 'test')
plt.legend(loc = 'upper right')
plt.title ('Training and validation loss')


# In[241]:


# plot accuracy learning curves
plt.plot(epochs, training_history.history['acc'], label = 'train')
plt.plot(epochs, training_history.history['val_acc'], label = 'test')
plt.legend(loc = 'upper right')
plt.title ('Training and validation accuracy')


# #### Fixing class imbalance

# #### Using Smote

# In[242]:


df['text_length'] = [len(i.split()) for i in df.Processed_Description_Final] 

print('min length:',df.text_length.min(), '\t' ,'max length:', df.text_length.max())


# In[243]:


max_features = 10000
maxlen = df.text_length.max()      # Add your max length here

# Tokeninzing the text
tokenizer = Tokenizer()
tokenizer.fit_on_texts(df['Processed_Description_Final'])


# In[244]:


# Transforming each text to a sequence of integers.
X = tokenizer.texts_to_sequences(df['Processed_Description_Final'])
#------------------------------------------------------------

# Get the Vocabulary size
vocab_size = len(tokenizer.word_index)
#-------------------------------------------------------------

# Padding the sequences to ensure that all sequences in a list have the same length
X = pad_sequences(X, maxlen = maxlen)
y = np.asarray(df['Accident_Level'])
#-------------------------------------------------------------

print("Number of Samples:", len(X))


# In[245]:


from imblearn.over_sampling import SMOTE
from collections import Counter

counter = Counter(df['Accident_Level'].to_list())
print('Before',counter)

# oversampling the train dataset using SMOTE
smt = SMOTE()
labels = df['Accident_Level'].tolist()
X_smote, y_smote = smt.fit_resample(X, y)

X_train_smote, X_test_smote, y_train_smote, y_test_smote = train_test_split(X_smote, y_smote, stratify=y_smote, random_state=1)   

counter = Counter(y_train_smote)
print('After',counter)


# In[246]:


X_smote


# In[247]:


X_train_smote.shape


# In[248]:


X_test_smote.shape


# In[249]:


build_model_train(X_train_smote, y_train_smote, X_test_smote, y_test_smote)


# #### Using Neural Network for BOW model after balancing the class

# In[250]:


# Implementing Neural Networks Bag-of-words model after balancing the class. 

epochs = 100
batch_size = 12
loss = "categorical_crossentropy"
optimizer = "adam"
metrics = ["accuracy"]

# early_stopping = EarlyStopping(monitor='val_loss', mode='min', verbose=0, patience=3)

# Build neural network
smote_model = Sequential()
smote_model.add(Dense(512, activation='relu'))
smote_model.add(Dense(256, activation='relu'))
smote_model.add(Dense(5, activation='softmax'))
smote_model.compile(loss=loss, optimizer=optimizer, metrics= metrics)


# In[251]:


y_train_smote_dummy = pd.get_dummies(y_train_smote) # One-hot encoding
y_test_smote_dummy = pd.get_dummies(y_test_smote) # One-hot encoding

history=smote_model.fit(X_train_smote, y_train_smote_dummy, epochs=epochs, validation_data=(X_test_smote, y_test_smote_dummy), batch_size=batch_size)


# In[252]:


# Validating the model on test set
y_test_smote_dummy = pd.get_dummies(y_test_smote)
loss, accuracy = smote_model.evaluate(X_test_smote, y_test_smote_dummy, verbose = 0)
loss, accuracy


# In[253]:


plot_model(smote_model, to_file='smote_model.png', show_shapes=True, show_layer_names=True)


# In[254]:


import matplotlib.pyplot as plt

f, (ax1, ax2) = plt.subplots(1, 2, figsize = (15, 7.5))
f.suptitle('Monitoring the performance of the model')

ax1.plot(history.history['loss'], label = 'Train')
ax1.plot(history.history['val_loss'], label = 'Test')
ax1.set_title('Model Loss')
ax1.legend(['Train', 'Test'])

ax2.plot(history.history['accuracy'], label = 'Train')
ax2.plot(history.history['val_accuracy'], label = 'Test')
ax2.set_title('Model Accuracy')
ax2.legend(['Train', 'Test'])

plt.show()


# #### Text Augmentation

# In[255]:


df_text = df.copy()  #tried augmenting all 
df_text.head()


# In[256]:


import pandas as pd
translator = google_translator()


# In[257]:



# Generating more data for minority classes in dependent variable Using Back Translation

translator = google_translator()  
def backTranslate(text):
    translate_text = translator.translate(text, lang_tgt='pt-br')  
    translate_text = translator.translate(translate_text, lang_tgt='en') 
    return translate_text 


# In[258]:


df_text['Description']=df_text['Description'].apply(lambda x: translator.translate(x,lang_tgt ='pt-br'))


# In[259]:


df_text['Description']=df_text['Description'].apply(lambda x: translator.translate(x,lang_tgt ='en'))


# In[260]:


# Concatenating the new datapoints extracted from the backtranslation technique with the original dataset 
new_df_text = pd.concat([df_text, df.drop_duplicates()]).reset_index(drop = True)
new_df_text = new_df_text.drop_duplicates()
new_df_text.count()


# In[261]:


new_df_text.head(2)


# In[262]:


def des_cleaning(text):

    # Initialize the object for Lemmatizer class
    lemmatizer = nltk.stem.WordNetLemmatizer()

    # Set the stopwords to English
    stopwords = nltk.corpus.stopwords.words('english')

    # Normalize the text in order deal with accented words and unicodes
    text = (unicodedata.normalize('NFKD', text).encode('ascii', 'ignore').decode('utf-8', 'ignore').lower())

    # Consider only alphabets and numbers from the text
    words = re.sub(r'[^a-zA-Z.,!?/:;\"\'\s]', '', text).split()

    # Consider the words which are not in stopwords of english and lemmatize them
    lemmatizer = nltk.stem.WordNetLemmatizer()
    lems = [lemmatizer.lemmatize(i) for i in words if i not in stopwords]

    # #remove non-alphabetical characters like '(', '.' or '!'
    # alphas = [i for i in lems if (i.isalpha() or i.isnumeric()) and (i not in stopwords)]

    words = [w for w in lems if len(w)>2]

    return words


# In[263]:


# Nlp preprocessing on the augumented text data
new_df_text['Augmented'] = new_df_text.apply(lambda x: " ".join(des_cleaning(x.Description)), axis=1)


# In[264]:


new_df_text.Accident_Level.value_counts(), df['Accident_Level'].value_counts()


# In[265]:


X_train_aug, X_test_aug, y_train_aug, y_test_aug = train_test_split(new_df_text['Augmented'], new_df_text['Accident_Level'], test_size=0.3, random_state=42)

print('Training utterances: {}'.format(X_train_aug.shape[0]))
print('Validation utterances: {}'.format(X_test_aug.shape[0]))


# #### Text Augmentation

# In[266]:


# Import libraries
try:
    import textaugment, gensim
except ModuleNotFoundError:
    get_ipython().system('pip -q install textaugment gensim')
    import textaugment, gensim

from textaugment import Wordnet

pf = pd.concat([pd.DataFrame(X_train_aug, columns =["Augmented"]).reset_index(drop = True), 
                pd.DataFrame(y_train_aug, columns =["Accident_Level"]).reset_index(drop = True)], axis =1)
pf.head()


# In[267]:


y_train_aug = le.fit_transform(y_train_aug).astype(np.int8)
pf.Accident_Level = le.fit_transform(pf.Accident_Level).astype(np.int8)
y_train_aug[0:3]


# In[268]:


text = np.array(pf[(pf['Accident_Level'] == 0) | (pf['Accident_Level'] == 4) | (pf['Accident_Level'] == 1)]['Augmented'], dtype = str)
ytext = np.array(pf[(pf['Accident_Level'] == 0) | (pf['Accident_Level'] == 4) | (pf['Accident_Level'] == 1)]['Accident_Level'], dtype = np.int8)
ytext.dtype


# In[269]:


from collections import Counter
counter = Counter(y_train_aug)
print('Before',counter) # Accident Level Distribution for training Data


# #### Performing augmentation on training data -- Can be ignored for now

# In[270]:


# This functions takes in text to be augmented, its target as well as the augmentation model used and adds augmented rows to Training data
augmentedtxt = pd.DataFrame()

# AS OF NOW WE ARE NOT USING THIS TRAINING SET FOR OUR MODEL 
def augment(txtarray, ytxtarray, model):
    #create an empty dataframe
    pf_text = pd.DataFrame()

    # loop through all rows and augment data, also append it to the df created
    for i,x in enumerate(txtarray):
        taug = model.augment(str(x))
        if taug == str(x):
            continue
            # do not add duplicate data if augmentation doesnt modify the text
        else:
            pf_text = pf_text.append(pd.Series([taug,ytxtarray[i].astype(np.int8)], index = ['Augmented', 'Accident_Level']), ignore_index=True)
    #concatenating augmented data with the existing training dataframe
    final = pd.concat([pf_text, pf])
    augmentedtxt.append(pf_text)
    #updating the training data set
    X_train_aug = np.array(final.Augmented)
    y_train_aug = np.array(final.Accident_Level.astype(np.int8))
    #See the counts of target variale within the training set
    counter = Counter(y_train_aug)
    print('After',counter)
    return final.reset_index(drop = True)


# In[271]:


import nltk
nltk.download('averaged_perceptron_tagger')
t = Wordnet(n=True, p=0.7)
pf = augment(text, ytext,t)
pf['Accident_Level'] = pf['Accident_Level'].astype(np.int8)


# In[272]:


ftext = np.array(pf[pf['Accident_Level'] == 4], dtype = str)
fytext = np.array(pf[pf['Accident_Level'] == 4]['Accident_Level'], dtype = np.int8)


# In[273]:


from textaugment import Translate
#t = Translate(src="en", to="pt")
t = Wordnet( p=0.6, runs =5)
pf =augment(ftext, fytext,t)


# In[274]:


#Adding augmented data from minority classes into main data set
new_df_text = pd.concat([new_df_text, augmentedtxt], axis=1)


# In[275]:


# Getting the length of the each description
pf['sen_length'] = [len(i.split()) for i in pf['Augmented']] 

print('min length:', pf.sen_length.min(), '\t' ,'max length:', pf.sen_length.max())


# In[276]:


# Tokeninzing the text
tokenizer = Tokenizer()
tokenizer.fit_on_texts(new_df_text['Augmented'])


# In[277]:


# Transforming each text to a sequence of integers.
X = tokenizer.texts_to_sequences(new_df_text['Augmented'])
#------------------------------------------------------------

# Padding the sequences to ensure that all sequences in a list have the same length
X = pad_sequences(X, maxlen = pf.sen_length.max())
#-------------------------------------------------------------

print("Number of Samples:", len(X))


# In[278]:


counter = Counter(new_df_text['Accident_Level'].to_list())
print('Before',counter)

# oversampling the train dataset using SMOTE
smt = SMOTE()
labels = new_df_text['Accident_Level'].tolist()
X_smote, y_smote = smt.fit_resample(X, labels)

X_train_smote, X_test_smote, y_train_smote, y_test_smote = train_test_split(X_smote, y_smote, stratify=y_smote, random_state=1)   

counter = Counter(y_train_smote)
print('After',counter)


# In[279]:


build_model_train(X_train_smote, y_train_smote, X_test_smote, y_test_smote)


# #### Using Cross Validation for Bagging Classifier

# In[280]:


# Here implementing cross validation using bagging classifer as it is giving the bettwe accuracy compared to other ML models
from sklearn.model_selection import train_test_split, cross_val_score
Bag_clf = BaggingClassifier(base_estimator = RandomForestClassifier(n_estimators=150, max_features='sqrt'), 
                            n_estimators=200,
                            random_state=52)

scores =[]
def model(algo, x, y):  # defining a function
    cross_val = cross_val_score(algo, x, y, cv=3) # 3 splits
    print ('************************')
    scores.append(cross_val)

    # Report Performance
    print ("cv-mean score :",'{:.2f}%'.format(cross_val.mean()*100)) # printing the average of all the 3 scores
    print ("cv-std  :",'{:.2f}%'.format(cross_val.std()*100))   # printing the standard deviation to check the spread among all the scores


# In[281]:


print('Bagging classifier cv score')
model(Bag_clf, X_smote, y_smote)


# In[282]:


# plot scores
sns.distplot(scores)
plt.show()
# confidence intervals
alpha = 95       # for 95% confidence level
lower =  np.mean(scores)-(np.std(scores)*2) # minus two standard deviation
upper = np.mean(scores)+(np.std(scores)*2)  # plus two standard deviation
print('{}% confidence interval {:.1f}% and {:.1f}%'.format(alpha, lower*100, upper*100))


# #### Bagging classifier giving best results using smote

# In[283]:


Bag_clf = BaggingClassifier(base_estimator = RandomForestClassifier(n_estimators=100, max_features='sqrt'), 
                            n_estimators=200,
                            random_state=52)
                            
Bag_clf.fit(X_train_smote, y_train_smote) # fitting the model 
print('\nTest score:', '{:.2f}%'.format(Bag_clf.score(X_test_smote, y_test_smote)*100)) # evaluating it on test set


# In[284]:


# Making predictions on test data
y_pred = Bag_clf.predict(X_test_smote)
print('\t***********Classification Report*********** \n', classification_report(y_pred, y_test_smote))
 
# Creation of confusion matrix
cm = confusion_matrix(y_test_smote, y_pred)
cm = pd.DataFrame(cm, index = ['I', 'II', 'III', 'IV', 'V'] , columns = [0, 1, 2, 3, 4])
 
# Plotting the confusion matrix
plt.title('Confusion Matrix between predictions and actuals')
sns.heatmap(cm, annot=True, fmt = '', cbar=False, cmap='RdPu', linecolor='black', linewidths=0.1);


# In[285]:


from sklearn.metrics import roc_curve
# roc_curve() which computes the ROC for classifier. It returns the FPR, TPR, and threshold values

pred_prob = Bag_clf.predict_proba(X_test_smote)

# roc curve for classes
fpr = {}
tpr = {}
thresh ={}

n_class = 5

for i in range(n_class): # looping on number of classes and computing three metrics for each class
    # Compute Receiver operating characteristic (ROC), the function returns
    fpr[i], tpr[i], thresh[i] = roc_curve(y_true = le.fit_transform(y_test_smote), y_score = pred_prob[:,i], pos_label=i)


# In[286]:


# plotting
plt.figure(figsize=(10,7))
plt.plot(fpr[0], tpr[0], linestyle='--',color='orange', label='Level I vs Rest')
plt.plot(fpr[1], tpr[1], linestyle='--',color='green', label='Level II vs Rest')
plt.plot(fpr[2], tpr[2], linestyle='--',color='blue', label='Level III vs Rest')
plt.plot(fpr[3], tpr[3], linestyle='--',color='red', label='Level IV vs Rest')
plt.plot(fpr[4], tpr[4], linestyle='--',color='black', label='Level V vs Rest')

plt.title('ROC curve comparision against each of the classes')
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive rate')
plt.legend(loc='best')


# In[287]:


df.info()


# ### Step 5: Choose the best performing model classifier and pickle it.

# In[288]:


#Pickle file used to store the model

import pickle
#Bag_clf.fit(X_smote, y_smote)
pickle.dump(Bag_clf, open('nlp_chatbot.sav','wb'))


# ## Milestone 3

# ### Input: Pickled model from milestone 2

# ### Process

# ### Step 1: Design a clickable UI which can automate tasks performed under milestone 1

# ### Step 2: Design a clickable UI which can automate tasks performed under milestone 2

# ### Step 3: Design a clickable UI based chatbot interface

# #### Function used for UI integration -- takes description as input vectorizes and predicts it via our bagging classifier
# 

# In[289]:


# Function used for UI integration -- takes description as input vectorizes and predicts it via our bagging classifier Covers Steps 1 and 2 which does the stuff for Milestone 1 and Milestone 2.
def predict(message):
    data = " ".join(des_cleaning(message))
    print(data)
    x = tokenizer.texts_to_sequences([data])
    # Padding the sequences to ensure that all sequences in a list have the same length
    message = pad_sequences(x, maxlen = 107)
    my_prediction = Bag_clf.predict(message)
    print(my_prediction)
    if my_prediction == 0:
        my_prediction = 'Accident Level I'
    elif my_prediction == 1:
        my_prediction = 'Accident Level II'
    elif my_prediction == 2:
        my_prediction = 'Accident Level III'
    elif my_prediction == 3:
        my_prediction = 'Accident Level IV'
    else: 
        my_prediction = 'Accident Level V'
    return my_prediction


# **For Prediction of Accident Level 1**

# In[290]:


predict("The worker Manuel was making the disconnection of the power cables of the gate that is at the intersection of Manco streets with Cajamarquilla in order to remove it. In circumstances that Mr. JosÃ© worker of the company ITS, was removing the rope tied in the body of the gate, this yields and falls pulling the warning post which hits the helmet of Mr. who He was standing at his side.")


# **For Prediction of Accident Level 2**

# In[291]:


predict("During the withdrawal of the metal form support screw in the Inside of well 2, when the bolt of the chain holder was loosened, the employee and a helper exerted force on the combination wrench, when the bolt came to loosen immediately, pressing the ring finger of the employee's right hand against the support.")


# **For Prediction of Accident Level 3**

# In[292]:


predict('In the city of Conchucos, of Ancash, participating in a patronal feast, representing the company, was mounted on a horse as part of the ceremony throwing fruits and toys to the people attending this public event, the noise of the materials pyrotechnics and people trying to collect the gifts caused the horse in front and very close to her horse to be frightened and kicked back hitting the lower limbs.')


# **For Prediction of Accident Level 4**

# In[293]:


predict('When observing the pulp overflow of the overflow reception drawer of the thickener, the filter operator approaches to verify the operation of the C7-26 pump, making sure that it was stopped. So press the keypad to start the pump and not getting the start, proceeds to remove the guard and manipulates the motor - pump transmission strips, being left hand imprisoned between the pulley of motor and transmission belt')


# **For Prediction of Accident Level 5**

# In[294]:


predict('Being approximately 20:57 hours of 03/22/2017; during the change of cables between the Z-332 power cell (locked cabinet) and the Z014 transformer; there is a loud noise followed by an oscillation of the electrical system. At that moment the collaborator Queneche  the company EISSA is found on the floor with his head inside an adjoining cell Z-132 (cabinet Not blocked - where he was not assigned to do any work), after having received an electric shock .')


# In[ ]:


#Creating GUI with tkinter
get_ipython().system('pip install tkinter')
### CREATE VIRTUAL DISPLAY ###
get_ipython().system('apt-get install -y xvfb # Install X Virtual Frame Buffer')
import os
os.system('Xvfb :1 -screen 0 1600x1200x16  &')    # create virtual display with size 1600x1200 and 16 bit color. Color can be changed to 24 or 8
os.environ['DISPLAY']=':1.0'    # tell X clients to use our virtual DISPLAY :1.0.
import tkinter
from tkinter import *
import random as r
import keras
#import NLP_Chatbot_Milestone_3 as NPro2

def send():
    msg = EntryBox.get("1.0",'end-1c').strip()
    EntryBox.delete("0.0",END)

    if msg != '':
        ChatLog.config(state=NORMAL)
        ChatLog.insert(END, "You: " + msg + '\n\n')
        ChatLog.config(foreground="#442265", font=("Verdana", 12 ))
        if msg.lower()=='hi' or msg.lower()=='hello' or msg.lower()=='howdy':
            res= r.choice(['Hi','Hello','How can I help you'])
        elif msg.lower()=='place' or msg.lower()=='where' or msg.lower()=='location' or msg.lower()=='country':
            res= r.choice(['Brazil','12 Cities in Brazil','Location is Brazil']) 
        elif msg.lower()=='name' or msg.lower()=='called' or msg.lower()=='usage' or msg.lower()=='nick name':
            res= r.choice(['Predict Bot','I am called Predict Bot','I go by the name Predict Bot','I am Predict Bot and I predict Accidents'])
        elif msg.lower()=='bye' or msg.lower()=='bye bye' or msg.lower()=='stop' or msg.lower()=='exit':
            res= r.choice(['Bye Bye','C u soon','So happy to help you.. C u soon'])
        #res = chatbot_response(msg)
        else:
            res=predict(msg)

        ChatLog.insert(END, "Predict Bot: " + res + '\n\n')

        ChatLog.config(state=DISABLED)
        ChatLog.yview(END)

base = Tk()
base.title("Welcome to Predict Bot")
base.geometry("400x500")
base.resizable(width=FALSE, height=FALSE)

#Create Chat window
ChatLog = Text(base, bd=0, bg="white", height="8", width="50", font="Arial",)

ChatLog.config(state=DISABLED)

#Bind scrollbar to Chat window
scrollbar = Scrollbar(base, command=ChatLog.yview, cursor="heart")
ChatLog['yscrollcommand'] = scrollbar.set

#Create Button to send message
SendButton = Button(base, font=("Verdana",12,'bold'), text="Send", width="12", height=5,
                    bd=0, bg="#aaee00", activebackground="#ab00aa",fg='#ffffff',
                    command= send )

#Create the box to enter message
EntryBox = Text(base, bd=0, bg="white",width="29", height="5", font="Arial")
#EntryBox.bind("<Return>", send)


#Place all components on the screen
scrollbar.place(x=376,y=6, height=386)
ChatLog.place(x=6,y=6, height=386, width=370)
EntryBox.place(x=6, y=401, height=60, width=250)
SendButton.place(x=260, y=401, height=60)

base.mainloop()


# In[ ]:


get_ipython().run_cell_magic('shell', '', 'jupyter nbconvert --to html /content/NLP_Chatbot_Complete.ipynb')

