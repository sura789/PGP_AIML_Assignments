#!/usr/bin/env python
# coding: utf-8

# In[1]:


from flask import Flask, request
import NLP_Chatbot_Complete as NPro2

# In[2]:


app=Flask(__name__)




@app.route("/result",methods=["POST"])
def result():
    output=request.get_json()
    if output is None:
        return {'predict':'none'}
    else:
        if len(output) != 1:
            return {"predict":"Should pass input"}
        else:
            desc=output["description"]
            resp={}
            res=NPro2.predict(desc)
            resp["predict"]=res
            return resp

# In[5]:


if __name__=="__main__":
    app.run(debug=True,port=2000)
else:
    print(__name__)


# In[ ]:




